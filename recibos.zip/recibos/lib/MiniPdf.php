<?php
declare(strict_types=1);

/**
 * Generador PDF pequeno, sin dependencias externas.
 * Cubre texto, rectangulos, lineas e imagenes JPEG para el recibo.
 */
class MiniPdf
{
    private $width = 595.28;
    private $height = 841.89;
    private $content = '';
    private $images = [];
    private $title;

    public function __construct(string $title = 'Documento PDF')
    {
        $this->title = $title;
    }

    public function pageWidth(): float
    {
        return $this->width;
    }

    public function pageHeight(): float
    {
        return $this->height;
    }

    public function rect(float $x, float $y, float $w, float $h, ?array $stroke = null, ?array $fill = null, float $lineWidth = 1): void
    {
        $pdfY = $this->height - $y - $h;
        $op = $fill !== null && $stroke !== null ? 'B' : ($fill !== null ? 'f' : 'S');

        $this->content .= "q\n";
        $this->content .= $this->formatNumber($lineWidth) . " w\n";
        if ($fill !== null) {
            $this->content .= $this->rgb($fill) . " rg\n";
        }
        if ($stroke !== null) {
            $this->content .= $this->rgb($stroke) . " RG\n";
        }
        $this->content .= $this->formatNumber($x) . ' ' . $this->formatNumber($pdfY) . ' ' .
            $this->formatNumber($w) . ' ' . $this->formatNumber($h) . " re {$op}\n";
        $this->content .= "Q\n";
    }

    public function line(float $x1, float $y1, float $x2, float $y2, array $color = [0, 0, 0], float $lineWidth = 1): void
    {
        $this->content .= "q\n";
        $this->content .= $this->rgb($color) . " RG\n";
        $this->content .= $this->formatNumber($lineWidth) . " w\n";
        $this->content .= $this->formatNumber($x1) . ' ' . $this->formatNumber($this->height - $y1) . " m\n";
        $this->content .= $this->formatNumber($x2) . ' ' . $this->formatNumber($this->height - $y2) . " l S\n";
        $this->content .= "Q\n";
    }

    public function text(float $x, float $y, string $text, int $size = 11, array $color = [0, 0, 0], bool $bold = false): void
    {
        $font = $bold ? '/F2' : '/F1';
        $safeText = $this->escapeText($text);

        $this->content .= "q\n";
        $this->content .= $this->rgb($color) . " rg\n";
        $this->content .= 'BT ' . $font . ' ' . $size . ' Tf 1 0 0 1 ' .
            $this->formatNumber($x) . ' ' . $this->formatNumber($this->height - $y) .
            " Tm ({$safeText}) Tj ET\n";
        $this->content .= "Q\n";
    }

    public function textBlock(float $x, float $y, float $w, string $text, int $size = 10, array $color = [0, 0, 0], bool $bold = false, float $lineHeight = 13): float
    {
        $maxChars = max(10, (int)floor($w / max(4, $size * 0.48)));
        $lines = [];
        $paragraphs = preg_split('/\R/', $text);

        foreach ($paragraphs as $paragraph) {
            $wrapped = $this->wrapText($paragraph, $maxChars);
            foreach ($wrapped as $line) {
                $lines[] = $line;
            }
        }

        foreach ($lines as $i => $line) {
            $this->text($x, $y + ($i * $lineHeight), $line, $size, $color, $bold);
        }

        return count($lines) * $lineHeight;
    }

    public function imageJpegData(string $bytes, float $x, float $y, float $w, float $h): bool
    {
        $info = @getimagesizefromstring($bytes);
        if ($info === false || !isset($info[2]) || (int)$info[2] !== IMAGETYPE_JPEG) {
            return false;
        }

        $name = 'Im' . (count($this->images) + 1);
        $this->images[] = [
            'name' => $name,
            'bytes' => $bytes,
            'width' => (int)$info[0],
            'height' => (int)$info[1],
        ];

        $pdfY = $this->height - $y - $h;
        $this->content .= "q\n";
        $this->content .= $this->formatNumber($w) . ' 0 0 ' . $this->formatNumber($h) . ' ' .
            $this->formatNumber($x) . ' ' . $this->formatNumber($pdfY) . " cm\n";
        $this->content .= '/' . $name . " Do\n";
        $this->content .= "Q\n";

        return true;
    }

    public function output(): string
    {
        $contentId = 6;
        $imageStartId = 7;
        $xObjects = '';

        foreach ($this->images as $i => $image) {
            $xObjects .= '/' . $image['name'] . ' ' . ($imageStartId + $i) . ' 0 R ';
        }

        $resources = '<< /Font << /F1 4 0 R /F2 5 0 R >>';
        if ($xObjects !== '') {
            $resources .= ' /XObject << ' . $xObjects . ' >>';
        }
        $resources .= ' >>';

        $objects = [];
        $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objects[2] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
        $objects[3] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' .
            $this->formatNumber($this->width) . ' ' . $this->formatNumber($this->height) .
            '] /Resources ' . $resources . ' /Contents ' . $contentId . ' 0 R >>';
        $objects[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objects[5] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $objects[$contentId] = '<< /Length ' . strlen($this->content) . " >>\nstream\n" .
            $this->content . "\nendstream";

        foreach ($this->images as $i => $image) {
            $id = $imageStartId + $i;
            $objects[$id] = '<< /Type /XObject /Subtype /Image /Width ' . $image['width'] .
                ' /Height ' . $image['height'] .
                ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' .
                strlen($image['bytes']) . " >>\nstream\n" . $image['bytes'] . "\nendstream";
        }

        ksort($objects);
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [0];

        foreach ($objects as $id => $object) {
            $offsets[$id] = strlen($pdf);
            $pdf .= $id . " 0 obj\n" . $object . "\nendobj\n";
        }

        $xrefPosition = strlen($pdf);
        $count = count($objects);
        $pdf .= "xref\n0 " . ($count + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";

        for ($i = 1; $i <= $count; $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        $title = $this->escapeText($this->title);
        $pdf .= "trailer\n<< /Size " . ($count + 1) . " /Root 1 0 R /Info << /Title ({$title}) >> >>\n";
        $pdf .= "startxref\n{$xrefPosition}\n%%EOF";

        return $pdf;
    }

    private function rgb(array $color): string
    {
        $r = max(0, min(255, (int)($color[0] ?? 0))) / 255;
        $g = max(0, min(255, (int)($color[1] ?? 0))) / 255;
        $b = max(0, min(255, (int)($color[2] ?? 0))) / 255;

        return $this->formatNumber($r) . ' ' . $this->formatNumber($g) . ' ' . $this->formatNumber($b);
    }

    private function formatNumber($number): string
    {
        return rtrim(rtrim(number_format((float)$number, 3, '.', ''), '0'), '.');
    }

    private function escapeText(string $text): string
    {
        $converted = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);
        if ($converted === false) {
            $converted = preg_replace('/[^\x20-\x7E]/', '', $text);
        }

        $converted = str_replace(["\\", '(', ')', "\r", "\n"], ["\\\\", "\\(", "\\)", '', ' '], $converted);
        return $converted;
    }

    private function wrapText(string $text, int $maxChars): array
    {
        $words = preg_split('/\s+/', trim($text));
        $lines = [];
        $line = '';

        foreach ($words as $word) {
            $candidate = $line === '' ? $word : $line . ' ' . $word;
            if (strlen($candidate) > $maxChars && $line !== '') {
                $lines[] = $line;
                $line = $word;
            } else {
                $line = $candidate;
            }
        }

        if ($line !== '') {
            $lines[] = $line;
        }

        return $lines ?: [''];
    }
}
