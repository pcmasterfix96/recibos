<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

ejecutarSeguro(function (): void {
    $input = leerEntrada();
    $numServicio = validarCampo('NumServicio', $input['NumServicio'] ?? $input['numServicio'] ?? '', 'servicio');
    $pdo = obtenerConexion();
    $mesInput = $input['MES'] ?? $input['mes'] ?? '';
    $anioInput = $input['AÑO'] ?? $input['anio'] ?? '';
    $filtrarPeriodo = trim((string)$mesInput) !== '' || trim((string)$anioInput) !== '';
    $mes = null;
    $anio = null;

    if ($filtrarPeriodo) {
        $mes = (int)validarCampo('MES', $mesInput, 'mes');
        $anio = (int)validarCampo('AÑO', $anioInput, 'anio');
    }

    $stmtEquipo = $pdo->prepare('SELECT * FROM `Inventario Equipos` WHERE `NumServicio` = :servicio LIMIT 1');
    $stmtEquipo->execute([':servicio' => $numServicio]);
    $equipo = $stmtEquipo->fetch() ?: null;

    $stmtCliente = $pdo->prepare('SELECT * FROM `Inventario Clientes` WHERE `NumServicio` = :servicio LIMIT 1');
    $stmtCliente->execute([':servicio' => $numServicio]);
    $cliente = $stmtCliente->fetch() ?: null;

    if ($filtrarPeriodo) {
        $stmtPagos = $pdo->prepare('SELECT * FROM `pagos` WHERE `SERVICIOS` = :servicio AND `MES` = :mes AND `AÑO` = :anio ORDER BY `id` DESC');
        $stmtPagos->execute([
            ':servicio' => $numServicio,
            ':mes' => $mes,
            ':anio' => $anio,
        ]);
    } else {
        $stmtPagos = $pdo->prepare('SELECT * FROM `pagos` WHERE `SERVICIOS` = :servicio ORDER BY `AÑO` DESC, `MES` DESC, `id` DESC LIMIT 12');
        $stmtPagos->execute([':servicio' => $numServicio]);
    }
    $pagos = $stmtPagos->fetchAll();

    $stmtRed = $pdo->prepare('SELECT * FROM `DiagramaRed` WHERE `NumServicio` = :servicio ORDER BY `id` DESC');
    $stmtRed->execute([':servicio' => $numServicio]);
    $diagramaRed = $stmtRed->fetchAll();

    if (!$equipo && !$cliente && count($pagos) === 0 && count($diagramaRed) === 0) {
        responderJson(['ok' => false, 'mensaje' => 'No se encontraron registros para ese numero de servicio.'], 404);
    }

    responderJson([
        'ok' => true,
        'NumServicio' => $numServicio,
        'equipo' => $equipo,
        'cliente' => $cliente,
        'pagos' => $pagos,
        'periodoPagos' => $filtrarPeriodo ? ['MES' => $mes, 'AÑO' => $anio] : null,
        'diagramaRed' => $diagramaRed,
    ]);
});
