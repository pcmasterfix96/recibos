<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

iniciarSesion();
unset($_SESSION['pmf_admin_token']);

responderJson([
    'ok' => true,
    'mensaje' => 'Sesion administrativa cerrada.',
]);
