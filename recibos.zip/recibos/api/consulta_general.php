<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

ejecutarSeguro(function (): void {
    $input = leerEntrada();
    $mes = (int)validarCampo('MES', $input['MES'] ?? $input['mes'] ?? date('n'), 'mes');
    $anio = (int)validarCampo('AÑO', $input['AÑO'] ?? $input['anio'] ?? date('Y'), 'anio');
    $columnasPagos = columnasExistentes('pagos');

    $streamingActivoExpr = columnaExiste($columnasPagos, 'streaming_activo')
        ? 'COALESCE(p.`streaming_activo`, 0)'
        : '0';
    $costoStreamingExpr = columnaExiste($columnasPagos, 'costo_streaming')
        ? 'COALESCE(p.`costo_streaming`, 0)'
        : '0';
    $totalFinalExpr = columnaExiste($columnasPagos, 'total_con_streaming')
        ? 'COALESCE(p.`total_con_streaming`, COALESCE(p.`Paquete`, 0) + IF(' . $streamingActivoExpr . ' = 1, ' . $costoStreamingExpr . ', 0))'
        : 'COALESCE(p.`Paquete`, 0) + IF(' . $streamingActivoExpr . ' = 1, ' . $costoStreamingExpr . ', 0)';

    $sql = '
        SELECT
            e.`NumServicio` AS `NumServicio`,
            COALESCE(c.`Nombre del Cliente`, "") AS `Nombre del Cliente`,
            e.`Contraseña` AS `Contraseña`,
            e.`Fecha de Instalacion` AS `Fecha de Instalacion`,
            e.`Modelo` AS `Modelo`,
            e.`Número de Serie` AS `Número de Serie`,
            COALESCE(c.`Megas`, "") AS `Megas`,
            COALESCE(p.`Paquete`, 0) AS `Paquete`,
            COALESCE(p.`ESTATUSPAGO`, "Sin pago") AS `Estatus pago`,
            ' . $streamingActivoExpr . ' AS `streaming_activo`,
            ' . $costoStreamingExpr . ' AS `Costo streaming`,
            ' . $totalFinalExpr . ' AS `Total final`,
            COALESCE(c.`Numero de Telefono`, "") AS `Numero de Telefono`,
            COALESCE(c.`Cordenadas`, "") AS `Cordenadas`,
            COALESCE(red.`NAP`, "") AS `NAP`
        FROM `Inventario Equipos` e
        LEFT JOIN `Inventario Clientes` c
            ON c.`NumServicio` = e.`NumServicio`
        LEFT JOIN `pagos` p
            ON p.`id` = (
                SELECT p2.`id`
                FROM `pagos` p2
                WHERE p2.`SERVICIOS` = e.`NumServicio`
                  AND p2.`MES` = :mes
                  AND p2.`AÑO` = :anio
                ORDER BY p2.`id` DESC
                LIMIT 1
            )
        LEFT JOIN (
            SELECT
                `NumServicio`,
                GROUP_CONCAT(`NAP` ORDER BY `id` SEPARATOR ", ") AS `NAP`
            FROM `DiagramaRed`
            GROUP BY `NumServicio`
        ) red
            ON red.`NumServicio` = e.`NumServicio`
        ORDER BY e.`NumServicio` ASC
    ';

    $stmt = obtenerConexion()->prepare($sql);
    $stmt->execute([
        ':mes' => $mes,
        ':anio' => $anio,
    ]);
    $registros = $stmt->fetchAll();

    $totalPaquetes = 0.0;
    $totalStreaming = 0.0;
    $totalFinal = 0.0;

    foreach ($registros as &$registro) {
        $streamingActivo = (int)($registro['streaming_activo'] ?? 0) === 1;
        $costoStreaming = $streamingActivo ? (float)($registro['Costo streaming'] ?? 0) : 0.0;
        $registro['Streaming'] = $streamingActivo ? 'Sí' : 'No';
        $registro['Costo streaming'] = number_format($costoStreaming, 2, '.', '');
        $registro['Paquete'] = number_format((float)($registro['Paquete'] ?? 0), 2, '.', '');
        $registro['Total final'] = number_format((float)($registro['Total final'] ?? 0), 2, '.', '');

        $totalPaquetes += (float)$registro['Paquete'];
        $totalStreaming += $costoStreaming;
        $totalFinal += (float)$registro['Total final'];
        unset($registro['streaming_activo']);
    }
    unset($registro);

    responderJson([
        'ok' => true,
        'periodo' => [
            'MES' => $mes,
            'AÑO' => $anio,
        ],
        'resumen' => [
            'total_paquetes' => number_format($totalPaquetes, 2, '.', ''),
            'total_streaming' => number_format($totalStreaming, 2, '.', ''),
            'total_final' => number_format($totalFinal, 2, '.', ''),
        ],
        'registros' => $registros,
    ]);
});
