<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

ejecutarSeguro(function (): void {
    $input = leerEntrada();

    if (!autenticacionValida($input)) {
        responderJson(['ok' => false, 'mensaje' => 'No autorizado.'], 401);
    }

    $config = resolverTabla((string)($input['tabla'] ?? ''));
    $clave = obtenerClaveRegistro($config, $input);

    $sql = 'DELETE FROM ' . qid($config['tabla']) .
        ' WHERE ' . qid($config['primaria']) . ' = :clave_registro LIMIT 1';

    $stmt = obtenerConexion()->prepare($sql);
    $stmt->execute([':clave_registro' => $clave]);

    responderJson([
        'ok' => true,
        'mensaje' => 'Registro eliminado correctamente.',
        'filas' => $stmt->rowCount(),
    ]);
});
