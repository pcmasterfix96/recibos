<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/../lib/MiniPdf.php';

function nombreMes(int $mes): string
{
    $meses = [
        1 => 'Enero',
        2 => 'Febrero',
        3 => 'Marzo',
        4 => 'Abril',
        5 => 'Mayo',
        6 => 'Junio',
        7 => 'Julio',
        8 => 'Agosto',
        9 => 'Septiembre',
        10 => 'Octubre',
        11 => 'Noviembre',
        12 => 'Diciembre',
    ];

    return $meses[$mes] ?? (string)$mes;
}

function extraerJpegDesdeDataUrl(string $dataUrl): ?string
{
    if (!preg_match('/^data:image\/jpe?g;base64,(.+)$/', $dataUrl, $matches)) {
        return null;
    }

    $bytes = base64_decode($matches[1], true);
    return $bytes === false ? null : $bytes;
}

function textoValor($valor, string $fallback = 'No registrado'): string
{
    $texto = trim((string)$valor);
    return $texto === '' ? $fallback : $texto;
}

function dibujarCampo(MiniPdf $pdf, float $x, float $y, string $label, string $valor, float $ancho = 220): void
{
    $pdf->text($x, $y, $label, 8, [89, 104, 120], true);
    $pdf->textBlock($x, $y + 15, $ancho, $valor, 11, [20, 31, 45], false, 13);
}

function dibujarGraficaFallback(MiniPdf $pdf, float $x, float $y, float $w, float $h, int $megasConsumidos, int $megasContratados): void
{
    $max = max($megasConsumidos, $megasContratados, 1);
    $barMaxHeight = $h - 48;
    $barHeight = max(8, ($megasConsumidos / $max) * $barMaxHeight);
    $barWidth = 58;
    $barX = $x + ($w / 2) - ($barWidth / 2);
    $barY = $y + $h - 34 - $barHeight;

    $pdf->rect($x, $y, $w, $h, [209, 216, 224], [255, 255, 255], 0.8);
    $pdf->text($x + 16, $y + 24, 'Megas consumidos', 12, [20, 31, 45], true);
    $pdf->line($x + 34, $y + $h - 34, $x + $w - 24, $y + $h - 34, [148, 163, 184], 0.8);
    $pdf->rect($barX, $barY, $barWidth, $barHeight, null, [31, 111, 139], 1);
    $pdf->text($barX + 10, $barY - 10, (string)$megasConsumidos, 11, [31, 111, 139], true);
    $pdf->text($x + 38, $y + $h - 14, 'Consumo mensual', 9, [71, 85, 105]);
}

function colorEstatusRecibo(string $estatus): array
{
    $normalizado = strtolower($estatus);

    if (strpos($normalizado, 'pagado') !== false && strpos($normalizado, 'no pagado') === false) {
        return [47, 133, 90];
    }

    if (strpos($normalizado, 'pend') !== false || strpos($normalizado, 'parcial') !== false) {
        return [183, 121, 31];
    }

    return [180, 35, 24];
}

function detallePagoStreaming(array $pago): array
{
    $subtotal = (float)($pago['Paquete'] ?? 0);
    $streamingActivo = (int)($pago['streaming_activo'] ?? 0) === 1;
    $costoStreamingConfigurado = (float)($pago['costo_streaming'] ?? 30);
    $costoStreamingAplicado = $streamingActivo ? $costoStreamingConfigurado : 0.0;
    $total = isset($pago['total_con_streaming'])
        ? (float)$pago['total_con_streaming']
        : $subtotal + $costoStreamingAplicado;

    return [
        'subtotal' => $subtotal,
        'streaming_activo' => $streamingActivo,
        'costo_streaming' => $costoStreamingAplicado,
        'total' => $total,
    ];
}

ejecutarSeguro(function (): void {
    $input = leerEntrada();
    $numServicio = validarCampo('NumServicio', $input['NumServicio'] ?? $input['numServicio'] ?? '', 'servicio');
    $mes = (int)validarCampo('MES', $input['MES'] ?? $input['mes'] ?? '', 'mes');
    $anio = (int)validarCampo('AÑO', $input['AÑO'] ?? $input['anio'] ?? '', 'anio');
    $megasConsumidos = (int)validarCampo('Megas consumidos en el mes', $input['megasConsumidos'] ?? '', 'entero_positivo');
    $graficaJpeg = extraerJpegDesdeDataUrl((string)($input['grafica'] ?? ''));

    $pdo = obtenerConexion();

    $stmtCliente = $pdo->prepare('SELECT * FROM `Inventario Clientes` WHERE `NumServicio` = :servicio LIMIT 1');
    $stmtCliente->execute([':servicio' => $numServicio]);
    $cliente = $stmtCliente->fetch();

    if (!$cliente) {
        responderJson(['ok' => false, 'mensaje' => 'No existe cliente para ese numero de servicio.'], 404);
    }

    $stmtEquipo = $pdo->prepare('SELECT * FROM `Inventario Equipos` WHERE `NumServicio` = :servicio LIMIT 1');
    $stmtEquipo->execute([':servicio' => $numServicio]);
    $equipo = $stmtEquipo->fetch() ?: [];

    $stmtPagoPeriodo = $pdo->prepare('SELECT * FROM `pagos` WHERE `SERVICIOS` = :servicio AND `MES` = :mes AND `AÑO` = :anio ORDER BY `id` DESC LIMIT 1');
    $stmtPagoPeriodo->execute([
        ':servicio' => $numServicio,
        ':mes' => $mes,
        ':anio' => $anio,
    ]);
    $pagoPeriodo = $stmtPagoPeriodo->fetch();
    $pago = $pagoPeriodo;

    if (!$pago) {
        $stmtUltimoPago = $pdo->prepare('SELECT * FROM `pagos` WHERE `SERVICIOS` = :servicio ORDER BY `AÑO` DESC, `MES` DESC, `id` DESC LIMIT 1');
        $stmtUltimoPago->execute([':servicio' => $numServicio]);
        $pago = $stmtUltimoPago->fetch() ?: [];
    }

    $detallePago = detallePagoStreaming($pago);
    $paquete = number_format($detallePago['subtotal'], 2, '.', ',');
    $streamingTexto = $detallePago['streaming_activo'] ? 'Sí' : 'No';
    $costoStreaming = number_format($detallePago['costo_streaming'], 2, '.', ',');
    $totalFinal = number_format($detallePago['total'], 2, '.', ',');
    $estatusRecibo = $pagoPeriodo ? textoValor($pagoPeriodo['ESTATUSPAGO'] ?? 'Pendiente', 'Pendiente') : 'Pendiente';
    $estatusColor = colorEstatusRecibo($estatusRecibo);
    $megasContratados = (int)$cliente['Megas'];
    $periodo = nombreMes($mes) . ' ' . $anio;

    $pdf = new MiniPdf('Recibo PCMASTERFIX ' . $numServicio);
    $pdf->rect(0, 0, $pdf->pageWidth(), $pdf->pageHeight(), null, [246, 248, 251]);
    $pdf->rect(0, 0, $pdf->pageWidth(), 92, null, [31, 111, 139]);
    $pdf->text(42, 43, 'PCMASTERFIX', 24, [255, 255, 255], true);
    $pdf->text(42, 66, 'Recibo de servicio de internet', 11, [218, 241, 245]);
    $pdf->text(420, 43, 'Periodo', 9, [218, 241, 245], true);
    $pdf->text(420, 62, $periodo, 15, [255, 255, 255], true);
    $pdf->text(420, 82, 'Estatus: ' . $estatusRecibo, 10, [255, 255, 255], true);

    $pdf->rect(42, 116, 511, 232, [209, 216, 224], [255, 255, 255], 0.8);
    $pdf->text(62, 145, 'Datos del cliente', 15, [20, 31, 45], true);
    dibujarCampo($pdf, 62, 178, 'Numero de servicio', $numServicio);
    dibujarCampo($pdf, 62, 230, 'Nombre del cliente', textoValor($cliente['Nombre del Cliente'] ?? ''), 250);
    dibujarCampo($pdf, 62, 282, 'Colonia', textoValor($cliente['Colonia'] ?? ''), 250);

    dibujarCampo($pdf, 320, 178, 'Megas contratados', $megasContratados . ' Mbps', 190);
    dibujarCampo($pdf, 320, 230, 'Subtotal / paquete base', '$' . $paquete . ' MXN', 190);
    $pdf->text(320, 282, 'Servicio de streaming', 8, [89, 104, 120], true);
    $pdf->textBlock(320, 297, 190, $streamingTexto . ' - $' . $costoStreaming . ' MXN', 11, [20, 31, 45], false, 13);
    $pdf->text(320, 326, 'Estatus: ' . $estatusRecibo, 10, $estatusColor, true);

    $pdf->rect(42, 368, 511, 186, [209, 216, 224], [255, 255, 255], 0.8);
    $pdf->text(62, 397, 'Consumo del mes', 15, [20, 31, 45], true);
    $pdf->text(62, 423, 'Megas consumidos en el mes: ' . $megasConsumidos . ' Mbps', 11, [71, 85, 105], false);

    if ($graficaJpeg !== null && $pdf->imageJpegData($graficaJpeg, 82, 438, 430, 96)) {
        // La grafica llega desde el canvas del navegador.
    } else {
        dibujarGraficaFallback($pdf, 82, 430, 430, 110, $megasConsumidos, $megasContratados);
    }

    $pdf->rect(42, 574, 245, 174, [209, 216, 224], [255, 255, 255], 0.8);
    $pdf->text(62, 604, 'Datos bancarios', 14, [20, 31, 45], true);
    $pdf->textBlock(62, 630, 205, "Banco BBVA\nCuenta: 151 685 3142\nCuenta CLABE: 012 180 01516853142 4\nTarjeta de debito: 4152 3140 7424 5872\nNombre: Luis Angel Sanchez Loyo", 10, [20, 31, 45], false, 15);

    $pdf->rect(308, 574, 245, 174, [209, 216, 224], [255, 255, 255], 0.8);
    $pdf->text(328, 604, 'Resumen de pago', 14, [20, 31, 45], true);
    $pdf->text(328, 632, 'Subtotal: $' . $paquete . ' MXN', 11, [20, 31, 45]);
    $pdf->text(328, 655, 'Streaming: ' . $streamingTexto, 11, [20, 31, 45]);
    $pdf->text(328, 678, 'Costo streaming: $' . $costoStreaming . ' MXN', 11, [20, 31, 45]);
    $pdf->text(328, 707, 'Total final: $' . $totalFinal . ' MXN', 14, [31, 111, 139], true);
    $pdf->text(328, 732, 'Fecha de emision: ' . date('Y-m-d'), 9, [71, 85, 105]);

    $pdf->text(42, 790, 'Gracias por su pago. Conserve este recibo como comprobante.', 9, [71, 85, 105]);

    $contenido = $pdf->output();
    $archivo = 'recibo_' . preg_replace('/[^A-Za-z0-9_-]/', '_', $numServicio) . '_' . $mes . '_' . $anio . '.pdf';

    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . $archivo . '"');
    header('Content-Length: ' . strlen($contenido));
    echo $contenido;
    exit;
});
