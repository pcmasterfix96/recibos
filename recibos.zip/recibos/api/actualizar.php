<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

ejecutarSeguro(function (): void {
    $input = leerEntrada();

    if (!autenticacionValida($input)) {
        responderJson(['ok' => false, 'mensaje' => 'No autorizado.'], 401);
    }

    $config = resolverTabla((string)($input['tabla'] ?? ''));
    $clave = obtenerClaveRegistro($config, $input);
    $datos = prepararDatos($config, $input['datos'] ?? []);

    $sets = [];
    $params = [':clave_registro' => $clave];

    $i = 0;
    foreach ($datos as $columna => $valor) {
        $placeholder = ':v' . $i;
        $sets[] = qid($columna) . ' = ' . $placeholder;
        $params[$placeholder] = $valor;
        $i++;
    }

    $sql = 'UPDATE ' . qid($config['tabla']) .
        ' SET ' . implode(', ', $sets) .
        ' WHERE ' . qid($config['primaria']) . ' = :clave_registro LIMIT 1';

    $stmt = obtenerConexion()->prepare($sql);
    $stmt->execute($params);

    responderJson([
        'ok' => true,
        'mensaje' => 'Registro actualizado correctamente.',
        'filas' => $stmt->rowCount(),
    ]);
});
