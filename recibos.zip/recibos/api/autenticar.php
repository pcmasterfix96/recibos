<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

ejecutarSeguro(function (): void {
    $input = leerEntrada();
    $usuario = trim((string)($input['usuario'] ?? $input['user'] ?? ''));
    $password = (string)($input['password'] ?? $input['contrasena'] ?? '');

    if (!credencialesValidas($usuario, $password)) {
        responderJson(['ok' => false, 'mensaje' => 'Credenciales incorrectas.'], 401);
    }

    responderJson([
        'ok' => true,
        'mensaje' => 'Autenticacion correcta.',
        'token' => crearTokenAdmin(),
    ]);
});
