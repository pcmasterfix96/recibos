<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

ejecutarSeguro(function (): void {
    $input = leerEntrada();

    if (!autenticacionValida($input)) {
        responderJson(['ok' => false, 'mensaje' => 'No autorizado.'], 401);
    }

    $config = resolverTabla((string)($input['tabla'] ?? ''));
    $datos = prepararDatos($config, $input['datos'] ?? []);

    $columnas = array_keys($datos);
    $placeholders = [];
    $params = [];

    foreach ($columnas as $i => $columna) {
        $placeholder = ':v' . $i;
        $placeholders[] = $placeholder;
        $params[$placeholder] = $datos[$columna];
    }

    $sql = 'INSERT INTO ' . qid($config['tabla']) .
        ' (' . implode(', ', array_map('qid', $columnas)) . ')' .
        ' VALUES (' . implode(', ', $placeholders) . ')';

    $stmt = obtenerConexion()->prepare($sql);
    $stmt->execute($params);

    responderJson([
        'ok' => true,
        'mensaje' => 'Registro insertado correctamente.',
        'id' => $config['auto'] ? obtenerConexion()->lastInsertId() : null,
    ]);
});
