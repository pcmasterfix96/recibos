<?php
declare(strict_types=1);

require_once __DIR__ . '/conexion.php';

const ADMIN_USER = 'admin';
const ADMIN_PASS = 'Fam*SanLoy08';

function responderJson(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function leerEntrada(): array
{
    $raw = file_get_contents('php://input');
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if ($raw !== false && trim($raw) !== '' && stripos($contentType, 'application/json') !== false) {
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            responderJson(['ok' => false, 'mensaje' => 'JSON invalido.'], 400);
        }
        return $data;
    }

    return array_merge($_GET, $_POST);
}

function iniciarSesion(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function crearTokenAdmin(): string
{
    iniciarSesion();
    $_SESSION['pmf_admin_token'] = bin2hex(random_bytes(32));
    return $_SESSION['pmf_admin_token'];
}

function credencialesValidas(string $usuario, string $password): bool
{
    return hash_equals(ADMIN_USER, $usuario) && hash_equals(ADMIN_PASS, $password);
}

function autenticacionValida(array $input): bool
{
    $auth = isset($input['auth']) && is_array($input['auth']) ? $input['auth'] : $input;
    $token = trim((string)($auth['token'] ?? ''));

    if ($token !== '') {
        iniciarSesion();
        $tokenSesion = (string)($_SESSION['pmf_admin_token'] ?? '');
        if ($tokenSesion !== '' && hash_equals($tokenSesion, $token)) {
            return true;
        }
    }

    $usuario = trim((string)($auth['usuario'] ?? $auth['user'] ?? ''));
    $password = (string)($auth['password'] ?? $auth['contrasena'] ?? '');

    return credencialesValidas($usuario, $password);
}

function qid(string $identifier): string
{
    return '`' . str_replace('`', '``', $identifier) . '`';
}

function tablasPermitidas(): array
{
    return [
        'inventario_equipos' => [
            'tabla' => 'Inventario Equipos',
            'primaria' => 'NumServicio',
            'auto' => false,
            'columnas' => [
                'NumServicio',
                'Contraseña',
                'Fecha de Instalacion',
                'Estatus',
                'Modelo',
                'Número de Serie',
                'Contrato',
                'Condición del equipo',
            ],
            'reglas' => [
                'NumServicio' => 'servicio',
                'Fecha de Instalacion' => 'fecha',
            ],
        ],
        'inventario_clientes' => [
            'tabla' => 'Inventario Clientes',
            'primaria' => 'NumServicio',
            'auto' => false,
            'columnas' => [
                'NumServicio',
                'Nombre del Cliente',
                'Estatus',
                'Megas',
                'Numero de Telefono',
                'Colonia',
                'Municipio',
                'Cordenadas',
            ],
            'reglas' => [
                'NumServicio' => 'servicio',
                'Megas' => 'entero_positivo',
                'Numero de Telefono' => 'telefono',
            ],
        ],
        'pagos' => [
            'tabla' => 'pagos',
            'primaria' => 'id',
            'auto' => true,
            'columnas' => [
                'SERVICIOS',
                'Paquete',
                'ESTATUSPAGO',
                'MES',
                'AÑO',
                'COMENTARIO',
                'streaming_activo',
                'costo_streaming',
            ],
            'opcionales_si_no_existen' => [
                'streaming_activo',
                'costo_streaming',
                'total_con_streaming',
            ],
            'reglas' => [
                'SERVICIOS' => 'servicio',
                'Paquete' => 'moneda',
                'MES' => 'mes',
                'AÑO' => 'anio',
                'streaming_activo' => 'booleano',
                'costo_streaming' => 'moneda',
            ],
        ],
        'diagrama_red' => [
            'tabla' => 'DiagramaRed',
            'primaria' => 'id',
            'auto' => true,
            'columnas' => [
                'NumServicio',
                'NAP',
                'color',
            ],
            'reglas' => [
                'NumServicio' => 'servicio',
                'color' => 'color',
            ],
        ],
    ];
}

function resolverTabla(string $tabla): array
{
    $normalizada = strtolower(trim(str_replace([' ', '-'], '_', $tabla)));
    $aliases = [
        'inventario_equipos' => 'inventario_equipos',
        'inventario_clientes' => 'inventario_clientes',
        'pagos' => 'pagos',
        'diagramared' => 'diagrama_red',
        'diagrama_red' => 'diagrama_red',
    ];

    $clave = $aliases[$normalizada] ?? '';
    $mapa = tablasPermitidas();

    if ($clave === '' || !isset($mapa[$clave])) {
        responderJson(['ok' => false, 'mensaje' => 'Tabla no permitida.'], 400);
    }

    $config = $mapa[$clave];
    $config['clave_api'] = $clave;
    return $config;
}

function validarCampo(string $campo, $valor, string $regla = ''): string
{
    $valor = trim((string)$valor);

    if ($valor === '') {
        responderJson(['ok' => false, 'mensaje' => "El campo {$campo} es obligatorio."], 422);
    }

    if (strlen($valor) > 5000) {
        responderJson(['ok' => false, 'mensaje' => "El campo {$campo} es demasiado largo."], 422);
    }

    switch ($regla) {
        case 'servicio':
            if (strlen($valor) > 30 || !preg_match('/^[A-Za-z0-9._-]+$/', $valor)) {
                responderJson(['ok' => false, 'mensaje' => "{$campo} solo admite letras, numeros, punto, guion y guion bajo."], 422);
            }
            break;

        case 'fecha':
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $valor)) {
                responderJson(['ok' => false, 'mensaje' => "{$campo} debe tener formato YYYY-MM-DD."], 422);
            }
            [$anio, $mes, $dia] = array_map('intval', explode('-', $valor));
            if (!checkdate($mes, $dia, $anio)) {
                responderJson(['ok' => false, 'mensaje' => "{$campo} no es una fecha valida."], 422);
            }
            break;

        case 'entero_positivo':
            if (filter_var($valor, FILTER_VALIDATE_INT) === false || (int)$valor <= 0) {
                responderJson(['ok' => false, 'mensaje' => "{$campo} debe ser un entero positivo."], 422);
            }
            break;

        case 'telefono':
            if (!preg_match('/^[0-9+\-\s()]{7,30}$/', $valor)) {
                responderJson(['ok' => false, 'mensaje' => "{$campo} debe ser un telefono valido."], 422);
            }
            break;

        case 'moneda':
            if (!is_numeric($valor) || (float)$valor < 0) {
                responderJson(['ok' => false, 'mensaje' => "{$campo} debe ser un monto valido."], 422);
            }
            $valor = number_format((float)$valor, 2, '.', '');
            break;

        case 'booleano':
            $normalizado = strtolower($valor);
            if (in_array($normalizado, ['1', 'si', 'sí', 'true', 'on'], true)) {
                $valor = '1';
            } elseif (in_array($normalizado, ['0', 'no', 'false', 'off'], true)) {
                $valor = '0';
            } else {
                responderJson(['ok' => false, 'mensaje' => "{$campo} debe indicar Si o No."], 422);
            }
            break;

        case 'mes':
            if (filter_var($valor, FILTER_VALIDATE_INT) === false || (int)$valor < 1 || (int)$valor > 12) {
                responderJson(['ok' => false, 'mensaje' => "{$campo} debe estar entre 1 y 12."], 422);
            }
            break;

        case 'anio':
            if (filter_var($valor, FILTER_VALIDATE_INT) === false || (int)$valor < 2000 || (int)$valor > 2100) {
                responderJson(['ok' => false, 'mensaje' => "{$campo} debe estar entre 2000 y 2100."], 422);
            }
            break;

        case 'color':
            if (!preg_match('/^(#[0-9A-Fa-f]{6}|[A-Za-z0-9 _-]{2,40})$/', $valor)) {
                responderJson(['ok' => false, 'mensaje' => "{$campo} debe ser un color valido."], 422);
            }
            break;
    }

    return $valor;
}

function columnasExistentes(string $tabla): array
{
    static $cache = [];

    if (isset($cache[$tabla])) {
        return $cache[$tabla];
    }

    $stmt = obtenerConexion()->query('SHOW COLUMNS FROM ' . qid($tabla));
    $columnas = [];

    foreach ($stmt->fetchAll() as $columna) {
        $nombre = (string)($columna['Field'] ?? '');
        if ($nombre !== '') {
            $columnas[$nombre] = true;
        }
    }

    $cache[$tabla] = $columnas;
    return $columnas;
}

function columnaExiste(array $columnasExistentes, string $columna): bool
{
    return isset($columnasExistentes[$columna]);
}

function aplicarTotalesStreaming(array $datos, array $columnasExistentes): array
{
    if (!columnaExiste($columnasExistentes, 'total_con_streaming')) {
        return $datos;
    }

    $paquete = (float)($datos['Paquete'] ?? 0);
    $streamingActivo = (int)($datos['streaming_activo'] ?? 0) === 1;
    $costoStreaming = (float)($datos['costo_streaming'] ?? 30);
    $total = $paquete + ($streamingActivo ? $costoStreaming : 0);

    $datos['total_con_streaming'] = number_format($total, 2, '.', '');
    return $datos;
}

function prepararDatos(array $config, array $datos): array
{
    $salida = [];
    $reglas = $config['reglas'] ?? [];
    $columnasExistentes = columnasExistentes($config['tabla']);
    $opcionalesSiNoExisten = array_flip($config['opcionales_si_no_existen'] ?? []);

    if (($config['clave_api'] ?? '') === 'pagos') {
        $datos['streaming_activo'] = $datos['streaming_activo'] ?? '0';
        $datos['costo_streaming'] = $datos['costo_streaming'] ?? '30.00';
    }

    foreach ($config['columnas'] as $campo) {
        if (!columnaExiste($columnasExistentes, $campo)) {
            if (isset($opcionalesSiNoExisten[$campo])) {
                continue;
            }

            responderJson(['ok' => false, 'mensaje' => "La columna {$campo} no existe en la tabla {$config['tabla']}."], 500);
        }

        $salida[$campo] = validarCampo($campo, $datos[$campo] ?? '', $reglas[$campo] ?? '');
    }

    if (($config['clave_api'] ?? '') === 'pagos') {
        $salida = aplicarTotalesStreaming($salida, $columnasExistentes);
    }

    return $salida;
}

function obtenerClaveRegistro(array $config, array $input)
{
    $primaria = $config['primaria'];
    $clave = $input['clave'] ?? $input['id'] ?? $input[$primaria] ?? null;

    if ($clave === null || trim((string)$clave) === '') {
        responderJson(['ok' => false, 'mensaje' => 'Falta la clave del registro.'], 422);
    }

    if ($primaria === 'id') {
        if (filter_var($clave, FILTER_VALIDATE_INT) === false || (int)$clave <= 0) {
            responderJson(['ok' => false, 'mensaje' => 'El id del registro no es valido.'], 422);
        }
        return (int)$clave;
    }

    return validarCampo($primaria, $clave, 'servicio');
}

function ejecutarSeguro(callable $callback): void
{
    try {
        $callback();
    } catch (PDOException $e) {
        responderJson([
            'ok' => false,
            'mensaje' => 'Error de base de datos: ' . $e->getMessage(),
        ], 500);
    } catch (Throwable $e) {
        responderJson([
            'ok' => false,
            'mensaje' => 'Error del servidor: ' . $e->getMessage(),
        ], 500);
    }
}
