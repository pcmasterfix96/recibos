# PCMASTERFIX

Aplicacion web local para administrar inventario de equipos, clientes, pagos, diagrama de red y generacion de recibos PDF.

## Requisitos

- XAMPP con Apache, MySQL y PHP activos.
- Navegador moderno en la misma computadora o en otro dispositivo de la red local.
- MySQL con usuario `root` sin contraseña, o ajustar credenciales en `api/conexion.php`.

## Instalacion en XAMPP

1. Copia esta carpeta dentro de `C:\xampp\htdocs\pcmasterfix`.
2. Abre XAMPP Control Panel e inicia `Apache` y `MySQL`.
3. Entra a [phpMyAdmin](http://localhost/phpmyadmin).
4. Importa el archivo `database/pcmasterfix.sql`.
5. Abre la aplicacion en [http://localhost/pcmasterfix/](http://localhost/pcmasterfix/).

## Acceso desde la red local

1. Obtén la IP local de la computadora donde corre XAMPP, por ejemplo `192.168.1.50`.
2. Desde otro dispositivo conectado a la misma red abre `http://192.168.1.50/pcmasterfix/`.
3. Si no carga, revisa que el firewall de Windows permita conexiones entrantes a Apache.

## Base de datos

El script `database/pcmasterfix.sql` crea la base `pcmasterfix` con codificacion `utf8mb4` y estas tablas:

- `Inventario Equipos`
- `Inventario Clientes`
- `pagos`
- `DiagramaRed`

Las tablas relacionadas usan claves foraneas hacia `Inventario Equipos.NumServicio`.

### Migracion para streaming en pagos

Si ya tienes la base importada, no vuelvas a importar `database/pcmasterfix.sql` porque elimina y recrea tablas. Primero genera un respaldo logico y luego ejecuta:

```text
database/migrations/2026-06-12_streaming_pagos.sql
```

La migracion agrega en `pagos`:

- `streaming_activo`
- `costo_streaming`
- `total_con_streaming`

El sistema calcula `total_con_streaming` como `Paquete + costo_streaming` solo cuando `streaming_activo` esta habilitado. El costo predeterminado del streaming es `$30.00`.

## Credenciales de administracion

Para entrar a `Ingresar Datos` o `Buscar / Administrar`, y para insertar, modificar o eliminar registros, se solicita autenticacion. Cada recarga de la pagina cierra la autorizacion administrativa anterior y vuelve a pedir usuario y contraseña:

- Usuario: `admin`
- Contraseña: `Fam*SanLoy08`

La validacion se realiza en `api/autenticar.php`, `api/cerrar_sesion.php`, `api/insertar.php`, `api/actualizar.php` y `api/eliminar.php`.

## Estructura del proyecto

```text
pcmasterfix/
├── api/
│   ├── actualizar.php
│   ├── autenticar.php
│   ├── buscar.php
│   ├── conexion.php
│   ├── eliminar.php
│   ├── generar_recibo.php
│   ├── helpers.php
│   └── insertar.php
├── assets/
│   ├── css/styles.css
│   └── js/app.js
├── database/pcmasterfix.sql
├── lib/MiniPdf.php
├── index.html
└── README.md
```

## Generacion de recibos PDF

La pestaña `Generar Recibo PDF` es la primera pantalla al cargar `index.html`. Busca el cliente por `NumServicio`, toma los megas contratados como valor inicial y permite editar `Megas consumidos en el mes`. El recibo muestra el estatus del periodo (`Pagado`, `No pagado`, `Pendiente`, etc.); si no existe pago para el mes y año seleccionados, el estatus se muestra como `Pendiente`.

## Consulta general

En `Buscar / Administrar`, el boton `Generar consulta general` usa el mes y año indicados en la barra de busqueda. Muestra el campo `Paquete` junto a `Megas`, el estatus del pago, streaming, costo del streaming, total final y un resumen con total de paquetes, total de streaming y total final del periodo.

## Ajustes comunes

- Si MySQL tiene contraseña, cambia `$user` y `$pass` en `api/conexion.php`.
- Si el proyecto se coloca con otro nombre dentro de `htdocs`, usa la URL correspondiente.
- Si importas el SQL de nuevo, las tablas existentes se eliminan y se crean otra vez.
