USE `pcmasterfix`;

-- Ejecuta un respaldo lógico antes de correr esta migración:
-- mysqldump -u root pcmasterfix > pcmasterfix_backup_antes_streaming.sql

SET @schema_name = DATABASE();

SET @sql = IF(
  (
    SELECT COUNT(*)
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @schema_name
      AND TABLE_NAME = 'pagos'
      AND COLUMN_NAME = 'streaming_activo'
  ) = 0,
  'ALTER TABLE `pagos` ADD COLUMN `streaming_activo` TINYINT(1) NOT NULL DEFAULT 0 AFTER `COMENTARIO`',
  'SELECT ''La columna streaming_activo ya existe'' AS mensaje'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (
    SELECT COUNT(*)
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @schema_name
      AND TABLE_NAME = 'pagos'
      AND COLUMN_NAME = 'costo_streaming'
  ) = 0,
  'ALTER TABLE `pagos` ADD COLUMN `costo_streaming` DECIMAL(10,2) NOT NULL DEFAULT 30.00 AFTER `streaming_activo`',
  'SELECT ''La columna costo_streaming ya existe'' AS mensaje'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (
    SELECT COUNT(*)
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @schema_name
      AND TABLE_NAME = 'pagos'
      AND COLUMN_NAME = 'total_con_streaming'
  ) = 0,
  'ALTER TABLE `pagos` ADD COLUMN `total_con_streaming` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `costo_streaming`',
  'SELECT ''La columna total_con_streaming ya existe'' AS mensaje'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

UPDATE `pagos`
SET
  `costo_streaming` = IF(`costo_streaming` < 0, 30.00, `costo_streaming`),
  `total_con_streaming` = `Paquete` + IF(`streaming_activo` = 1, `costo_streaming`, 0);
