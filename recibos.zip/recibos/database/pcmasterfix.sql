CREATE DATABASE IF NOT EXISTS `pcmasterfix`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `pcmasterfix`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `DiagramaRed`;
DROP TABLE IF EXISTS `pagos`;
DROP TABLE IF EXISTS `Inventario Clientes`;
DROP TABLE IF EXISTS `Inventario Equipos`;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `Inventario Equipos` (
  `NumServicio` VARCHAR(30) NOT NULL,
  `Contraseña` VARCHAR(255) NOT NULL,
  `Fecha de Instalacion` DATE NOT NULL,
  `Estatus` VARCHAR(60) NOT NULL,
  `Modelo` VARCHAR(100) NOT NULL,
  `Número de Serie` VARCHAR(120) NOT NULL,
  `Contrato` VARCHAR(120) NOT NULL,
  `Condición del equipo` VARCHAR(120) NOT NULL,
  PRIMARY KEY (`NumServicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Inventario Clientes` (
  `NumServicio` VARCHAR(30) NOT NULL,
  `Nombre del Cliente` VARCHAR(150) NOT NULL,
  `Estatus` VARCHAR(60) NOT NULL,
  `Megas` INT NOT NULL,
  `Numero de Telefono` VARCHAR(30) NOT NULL,
  `Colonia` VARCHAR(120) NOT NULL,
  `Municipio` VARCHAR(120) NOT NULL,
  `Cordenadas` VARCHAR(150) NOT NULL,
  PRIMARY KEY (`NumServicio`),
  CONSTRAINT `fk_clientes_equipos`
    FOREIGN KEY (`NumServicio`)
    REFERENCES `Inventario Equipos` (`NumServicio`)
    ON UPDATE CASCADE
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `pagos` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `SERVICIOS` VARCHAR(30) NOT NULL,
  `Paquete` DECIMAL(10,2) NOT NULL,
  `ESTATUSPAGO` VARCHAR(60) NOT NULL,
  `MES` INT NOT NULL,
  `AÑO` INT NOT NULL,
  `COMENTARIO` TEXT NOT NULL,
  `streaming_activo` TINYINT(1) NOT NULL DEFAULT 0,
  `costo_streaming` DECIMAL(10,2) NOT NULL DEFAULT 30.00,
  `total_con_streaming` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  INDEX `idx_pagos_servicio_periodo` (`SERVICIOS`, `AÑO`, `MES`),
  CONSTRAINT `fk_pagos_equipos`
    FOREIGN KEY (`SERVICIOS`)
    REFERENCES `Inventario Equipos` (`NumServicio`)
    ON UPDATE CASCADE
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `DiagramaRed` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `NumServicio` VARCHAR(30) NOT NULL,
  `NAP` VARCHAR(100) NOT NULL,
  `color` VARCHAR(40) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_diagrama_servicio` (`NumServicio`),
  CONSTRAINT `fk_diagrama_equipos`
    FOREIGN KEY (`NumServicio`)
    REFERENCES `Inventario Equipos` (`NumServicio`)
    ON UPDATE CASCADE
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
