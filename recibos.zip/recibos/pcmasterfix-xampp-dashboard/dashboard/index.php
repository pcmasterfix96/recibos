<?php
declare(strict_types=1);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Dashboard de PC MasterFix para acceso rapido a herramientas, servicios e informacion de contacto.">
  <title>PC MasterFix | Dashboard</title>
  <link rel="icon" href="/dashboard/favicon.ico" sizes="any">
  <style>
    :root {
      --bg: #f4f7fb;
      --panel: #ffffff;
      --ink: #17212d;
      --muted: #617086;
      --line: #d8e0ea;
      --navy: #0f1720;
      --blue: #1769d8;
      --cyan: #14a7c7;
      --green: #1c9b62;
      --amber: #f4a72c;
      --danger: #d94646;
      --shadow: 0 18px 44px rgba(17, 24, 39, .12);
      --radius: 8px;
    }

    * {
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      margin: 0;
      background: var(--bg);
      color: var(--ink);
      font-family: Arial, Helvetica, sans-serif;
      line-height: 1.6;
    }

    a {
      color: inherit;
    }

    .site-shell {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .topbar {
      position: sticky;
      top: 0;
      z-index: 20;
      border-bottom: 1px solid rgba(255, 255, 255, .12);
      background: rgba(15, 23, 32, .97);
      color: #f8fafc;
      box-shadow: 0 10px 28px rgba(10, 15, 22, .28);
    }

    .topbar__inner {
      width: min(1180px, calc(100% - 32px));
      margin: 0 auto;
      padding: 14px 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      flex-wrap: wrap;
    }

    .brand {
      display: inline-flex;
      align-items: center;
      gap: 12px;
      min-width: 230px;
      text-decoration: none;
    }

    .brand__mark {
      width: 48px;
      height: 48px;
      display: block;
      flex: 0 0 auto;
    }

    .brand__mark img {
      width: 100%;
      height: 100%;
      display: block;
      object-fit: contain;
      filter: drop-shadow(0 6px 12px rgba(0, 0, 0, .22));
    }

    .brand__text {
      display: grid;
      line-height: 1.15;
    }

    .brand__name {
      font-size: 1.05rem;
      font-weight: 800;
      letter-spacing: 0;
    }

    .brand__tagline {
      color: #a9b7c9;
      font-size: .8rem;
    }

    .nav-actions {
      display: grid;
      grid-template-columns: 1fr;
      gap: 8px;
      width: 100%;
    }

    .nav-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      min-height: 42px;
      padding: 10px 14px;
      border: 1px solid rgba(255, 255, 255, .16);
      border-radius: 8px;
      background: rgba(255, 255, 255, .08);
      color: #f8fafc;
      text-decoration: none;
      font-weight: 700;
      white-space: nowrap;
      transition: transform .18s ease, background .18s ease, border-color .18s ease;
    }

    .nav-button:hover,
    .nav-button:focus-visible {
      transform: translateY(-1px);
      background: rgba(255, 255, 255, .14);
      border-color: rgba(255, 255, 255, .34);
      outline: none;
    }

    .nav-button svg,
    .social-link svg,
    .service-card svg,
    .metric svg {
      width: 18px;
      height: 18px;
      flex: 0 0 auto;
    }

    main {
      flex: 1;
    }

    .hero {
      color: #f8fafc;
      background:
        linear-gradient(135deg, rgba(15, 23, 32, .96), rgba(22, 105, 216, .82)),
        repeating-linear-gradient(90deg, rgba(255, 255, 255, .05) 0 1px, transparent 1px 52px);
    }

    .hero__inner {
      width: min(1180px, calc(100% - 32px));
      margin: 0 auto;
      padding: 54px 0 42px;
      display: grid;
      gap: 28px;
    }

    .hero h1 {
      max-width: 780px;
      margin: 0 0 14px;
      font-size: clamp(2rem, 7vw, 4.15rem);
      line-height: 1.02;
      letter-spacing: 0;
    }

    .hero p {
      max-width: 690px;
      margin: 0;
      color: #dce7f5;
      font-size: 1rem;
    }

    .hero-grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 12px;
    }

    .metric {
      display: flex;
      align-items: center;
      gap: 12px;
      min-height: 72px;
      padding: 16px;
      border: 1px solid rgba(255, 255, 255, .16);
      border-radius: var(--radius);
      background: rgba(255, 255, 255, .1);
    }

    .metric strong {
      display: block;
      font-size: 1rem;
    }

    .metric span {
      color: #cbd7e7;
      font-size: .88rem;
    }

    .section {
      width: min(1180px, calc(100% - 32px));
      margin: 0 auto;
      padding: 44px 0;
    }

    .section__header {
      display: grid;
      gap: 8px;
      margin-bottom: 22px;
    }

    .eyebrow {
      margin: 0;
      color: var(--blue);
      font-weight: 800;
      font-size: .78rem;
      text-transform: uppercase;
      letter-spacing: .08em;
    }

    h2 {
      margin: 0;
      font-size: clamp(1.65rem, 4vw, 2.45rem);
      line-height: 1.15;
      letter-spacing: 0;
    }

    .section__lead {
      max-width: 780px;
      margin: 0;
      color: var(--muted);
      font-size: 1rem;
    }

    .services-grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 14px;
    }

    .service-card {
      min-height: 128px;
      display: grid;
      align-content: start;
      gap: 10px;
      padding: 18px;
      border: 1px solid var(--line);
      border-radius: var(--radius);
      background: var(--panel);
      box-shadow: 0 10px 28px rgba(15, 23, 32, .06);
    }

    .service-card__icon {
      width: 40px;
      height: 40px;
      display: grid;
      place-items: center;
      border-radius: 8px;
      color: #ffffff;
      background: var(--blue);
    }

    .service-card:nth-child(2) .service-card__icon {
      background: var(--green);
    }

    .service-card:nth-child(3) .service-card__icon {
      background: var(--amber);
      color: #16212f;
    }

    .service-card:nth-child(4) .service-card__icon {
      background: var(--danger);
    }

    .service-card h3 {
      margin: 0;
      font-size: 1rem;
      line-height: 1.3;
    }

    .internet-section {
      background: #eaf0f8;
      border-top: 1px solid #d8e0ea;
      border-bottom: 1px solid #d8e0ea;
    }

    .carousel {
      position: relative;
      overflow: hidden;
      border: 1px solid var(--line);
      border-radius: var(--radius);
      background: #ffffff;
      box-shadow: var(--shadow);
    }

    .carousel:focus-visible {
      outline: 3px solid rgba(20, 167, 199, .45);
      outline-offset: 4px;
    }

    .carousel-track {
      display: flex;
      transition: transform .35s ease;
      will-change: transform;
    }

    .plan-slide {
      flex: 0 0 100%;
      min-height: 330px;
      padding: 28px;
      display: grid;
      align-content: center;
      gap: 18px;
      color: #f8fafc;
      background:
        linear-gradient(135deg, rgba(15, 23, 32, .92), rgba(23, 105, 216, .78)),
        linear-gradient(90deg, rgba(255, 255, 255, .08), rgba(255, 255, 255, 0));
    }

    .plan-slide:nth-child(2) {
      background:
        linear-gradient(135deg, rgba(16, 86, 73, .95), rgba(20, 167, 199, .72)),
        linear-gradient(90deg, rgba(255, 255, 255, .08), rgba(255, 255, 255, 0));
    }

    .plan-slide:nth-child(3) {
      background:
        linear-gradient(135deg, rgba(31, 41, 55, .95), rgba(244, 167, 44, .8)),
        linear-gradient(90deg, rgba(255, 255, 255, .08), rgba(255, 255, 255, 0));
    }

    .plan-name {
      width: fit-content;
      margin: 0;
      padding: 6px 10px;
      border: 1px solid rgba(255, 255, 255, .24);
      border-radius: 8px;
      color: #f8fafc;
      font-weight: 800;
      text-transform: uppercase;
      font-size: .75rem;
      letter-spacing: .08em;
    }

    .plan-price {
      margin: 0;
      font-size: clamp(3rem, 16vw, 5.4rem);
      font-weight: 900;
      line-height: .95;
      letter-spacing: 0;
    }

    .plan-speed {
      margin: 0;
      color: #edf5ff;
      font-size: clamp(1.35rem, 5vw, 2rem);
      font-weight: 800;
    }

    .plan-note {
      max-width: 520px;
      margin: 0;
      color: #dbe8f6;
    }

    .carousel-control {
      position: absolute;
      top: 50%;
      width: 42px;
      height: 42px;
      display: grid;
      place-items: center;
      border: 1px solid rgba(255, 255, 255, .28);
      border-radius: 8px;
      background: rgba(15, 23, 32, .62);
      color: #ffffff;
      cursor: pointer;
      transform: translateY(-50%);
      transition: background .18s ease, transform .18s ease;
    }

    .carousel-control:hover,
    .carousel-control:focus-visible {
      background: rgba(15, 23, 32, .84);
      outline: none;
    }

    .carousel-control:active {
      transform: translateY(-50%) scale(.97);
    }

    .carousel-control--prev {
      left: 12px;
    }

    .carousel-control--next {
      right: 12px;
    }

    .carousel-control svg {
      width: 22px;
      height: 22px;
    }

    .carousel-dots {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 16px;
      display: flex;
      justify-content: center;
      gap: 8px;
    }

    .carousel-dot {
      width: 34px;
      height: 10px;
      border: 0;
      border-radius: 8px;
      background: rgba(255, 255, 255, .42);
      cursor: pointer;
      transition: width .18s ease, background .18s ease;
    }

    .carousel-dot[aria-current="true"] {
      width: 52px;
      background: #ffffff;
    }

    .site-footer {
      margin-top: auto;
      color: #e5edf7;
      background: var(--navy);
    }

    .site-footer__inner {
      width: min(1180px, calc(100% - 32px));
      margin: 0 auto;
      padding: 26px 0;
      display: grid;
      gap: 18px;
      align-items: center;
    }

    .footer-copy {
      margin: 0;
      color: #a9b7c9;
      font-size: .92rem;
    }

    .social-links {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
    }

    .social-link {
      width: 44px;
      height: 44px;
      display: grid;
      place-items: center;
      border: 1px solid rgba(255, 255, 255, .16);
      border-radius: 8px;
      background: rgba(255, 255, 255, .08);
      color: #ffffff;
      text-decoration: none;
      transition: transform .18s ease, background .18s ease;
    }

    .social-link:hover,
    .social-link:focus-visible {
      transform: translateY(-1px);
      background: rgba(255, 255, 255, .16);
      outline: none;
    }

    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }

    @media (min-width: 560px) {
      .nav-actions {
        grid-template-columns: repeat(3, minmax(0, 1fr));
      }

      .hero-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
      }

      .services-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }

      .plan-slide {
        padding: 42px 72px;
      }
    }

    @media (min-width: 860px) {
      .topbar__inner {
        flex-wrap: nowrap;
      }

      .nav-actions {
        width: auto;
        grid-template-columns: repeat(3, auto);
      }

      .hero__inner {
        padding: 76px 0 56px;
      }

      .services-grid {
        grid-template-columns: repeat(4, minmax(0, 1fr));
      }

      .site-footer__inner {
        grid-template-columns: 1fr auto;
      }
    }

    @media (prefers-reduced-motion: reduce) {
      *,
      *::before,
      *::after {
        scroll-behavior: auto !important;
        transition-duration: .01ms !important;
        animation-duration: .01ms !important;
        animation-iteration-count: 1 !important;
      }
    }
  </style>
</head>
<body>
  <div class="site-shell">
    <header class="topbar">
      <div class="topbar__inner">
        <a class="brand" href="/dashboard/index.php" aria-label="PC MasterFix inicio">
          <span class="brand__mark" aria-hidden="true">
            <img src="/dashboard/favicon.ico" alt="">
          </span>
          <span class="brand__text">
            <span class="brand__name">PC MasterFix</span>
            <span class="brand__tagline">Tecnologia, soporte y seguridad</span>
          </span>
        </a>

        <nav class="nav-actions" aria-label="Accesos rapidos">
          <a class="nav-button" href="http://localhost/phpmyadmin/">
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <ellipse cx="12" cy="5" rx="8" ry="3"></ellipse>
              <path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5"></path>
              <path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"></path>
            </svg>
            phpMyAdmin
          </a>
          <a class="nav-button" href="http://10.0.0.253/nas/">
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="3" y="5" width="18" height="14" rx="2"></rect>
              <path d="M7 9h10"></path>
              <path d="M7 13h4"></path>
              <path d="M16 17h.01"></path>
            </svg>
            Pelis y series
          </a>
          <a class="nav-button" href="http://10.0.0.253/pcmasterfix/">
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <path d="M14 2v6h6"></path>
              <path d="M8 13h8"></path>
              <path d="M8 17h6"></path>
            </svg>
            Recibos
          </a>
        </nav>
      </div>
    </header>

    <main>
      <section class="hero" aria-labelledby="hero-title">
        <div class="hero__inner">
          <div>
            <h1 id="hero-title">Soluciones tecnologicas para hogar, negocio y seguridad.</h1>
            <p>PC MasterFix ofrece soporte tecnico confiable, reparaciones precisas e instalacion de sistemas para mantener tus equipos y servicios trabajando sin interrupciones.</p>
          </div>

          <div class="hero-grid" aria-label="Resumen de servicios">
            <div class="metric">
              <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 7h16"></path>
                <path d="M5 7l1.5 12h11L19 7"></path>
                <path d="M9 7V4h6v3"></path>
              </svg>
              <span><strong>Servicio tecnico</strong>Diagnostico y reparacion</span>
            </div>
            <div class="metric">
              <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 12h16"></path>
                <path d="M12 4v16"></path>
                <path d="M7 7h10v10H7z"></path>
              </svg>
              <span><strong>Internet</strong>Planes para cada necesidad</span>
            </div>
            <div class="metric">
              <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                <path d="M9 12l2 2 4-4"></path>
              </svg>
              <span><strong>Seguridad</strong>Camaras y alarmas</span>
            </div>
          </div>
        </div>
      </section>

      <section class="section" aria-labelledby="about-title">
        <div class="section__header">
          <p class="eyebrow">Quienes somos</p>
          <h2 id="about-title">Experiencia y compromiso en servicios tecnologicos.</h2>
          <p class="section__lead">Somos una empresa dedicada a brindar soluciones tecnologicas con atencion cercana, trabajo responsable y experiencia en reparacion, mantenimiento, conectividad y seguridad.</p>
        </div>

        <div class="services-grid" aria-label="Servicios principales">
          <article class="service-card">
            <span class="service-card__icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="4" width="18" height="12" rx="2"></rect>
                <path d="M8 20h8"></path>
                <path d="M12 16v4"></path>
              </svg>
            </span>
            <h3>Mantenimiento y reparacion de equipos de computo.</h3>
          </article>

          <article class="service-card">
            <span class="service-card__icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="7" width="20" height="10" rx="5"></rect>
                <path d="M7 12h4"></path>
                <path d="M9 10v4"></path>
                <path d="M17 11h.01"></path>
                <path d="M15 13h.01"></path>
              </svg>
            </span>
            <h3>Reparacion de consolas de videojuegos.</h3>
          </article>

          <article class="service-card">
            <span class="service-card__icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M6 9V3h12v6"></path>
                <rect x="6" y="14" width="12" height="7"></rect>
                <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
              </svg>
            </span>
            <h3>Reparacion de impresoras.</h3>
          </article>

          <article class="service-card">
            <span class="service-card__icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 7h10l2 3h4v7H4z"></path>
                <path d="M8 17v3"></path>
                <path d="M16 17v3"></path>
                <path d="M10 11h4"></path>
              </svg>
            </span>
            <h3>Venta e instalacion de camaras y alarmas de seguridad.</h3>
          </article>
        </div>
      </section>

      <section class="internet-section" aria-labelledby="internet-title">
        <div class="section">
          <div class="section__header">
            <p class="eyebrow">Servicios de Internet</p>
            <h2 id="internet-title">Paquetes disponibles</h2>
            <p class="section__lead">Elige el plan que mejor se ajuste al uso diario de tu hogar o negocio.</p>
          </div>

          <div class="carousel" id="internet-carousel" tabindex="0" aria-roledescription="carousel" aria-label="Planes de internet">
            <div class="carousel-track">
              <article class="plan-slide" aria-label="Plan 1, 15 MB">
                <p class="plan-name">Plan 1</p>
                <p class="plan-price">$360</p>
                <p class="plan-speed">15 MB</p>
                <p class="plan-note">Ideal para navegacion, mensajeria, estudio y uso cotidiano.</p>
              </article>

              <article class="plan-slide" aria-label="Plan 2, 25 MB">
                <p class="plan-name">Plan 2</p>
                <p class="plan-price">$460</p>
                <p class="plan-speed">25 MB</p>
                <p class="plan-note">Pensado para streaming, videollamadas y varios dispositivos conectados.</p>
              </article>

              <article class="plan-slide" aria-label="Plan 3, 40 MB">
                <p class="plan-name">Plan 3</p>
                <p class="plan-price">$560</p>
                <p class="plan-speed">40 MB</p>
                <p class="plan-note">Mayor capacidad para hogares activos, trabajo remoto y entretenimiento.</p>
              </article>
            </div>

            <button class="carousel-control carousel-control--prev" type="button" data-direction="-1" aria-label="Plan anterior">
              <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M15 18l-6-6 6-6"></path>
              </svg>
            </button>
            <button class="carousel-control carousel-control--next" type="button" data-direction="1" aria-label="Plan siguiente">
              <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M9 18l6-6-6-6"></path>
              </svg>
            </button>

            <div class="carousel-dots" role="tablist" aria-label="Seleccion de plan">
              <button class="carousel-dot" type="button" data-slide="0" aria-label="Ver Plan 1" aria-current="true"></button>
              <button class="carousel-dot" type="button" data-slide="1" aria-label="Ver Plan 2" aria-current="false"></button>
              <button class="carousel-dot" type="button" data-slide="2" aria-label="Ver Plan 3" aria-current="false"></button>
            </div>
          </div>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <div class="site-footer__inner">
        <p class="footer-copy">&copy; <?php echo date('Y'); ?> PC MasterFix. Panel principal.</p>
        <div class="social-links" aria-label="Canales de contacto">
          <a class="social-link" href="mailto:pcmasterfixgerencia@gmail.com" target="_blank" rel="noopener" aria-label="Enviar correo a PC MasterFix">
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"></path>
              <path d="M22 6l-10 7L2 6"></path>
            </svg>
            <span class="sr-only">Correo electronico</span>
          </a>
          <a class="social-link" href="https://wa.me/542941594799" target="_blank" rel="noopener noreferrer" aria-label="Abrir WhatsApp de PC MasterFix">
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">
              <path d="M12.04 2a9.9 9.9 0 0 0-8.52 14.98L2.1 22l5.15-1.35A9.9 9.9 0 1 0 12.04 2zm0 1.78a8.12 8.12 0 1 1-4.14 15.1l-.3-.18-3.05.8.81-2.98-.2-.31A8.12 8.12 0 0 1 12.04 3.78zm-3.45 4.1c-.17 0-.44.06-.67.32-.23.26-.88.86-.88 2.1s.9 2.43 1.03 2.6c.13.17 1.76 2.7 4.28 3.78.6.26 1.07.41 1.43.52.6.19 1.15.16 1.58.1.48-.07 1.47-.6 1.68-1.18.21-.58.21-1.08.15-1.18-.06-.1-.23-.16-.49-.29-.26-.13-1.47-.73-1.7-.81-.23-.09-.4-.13-.57.13-.17.26-.65.81-.8.98-.15.17-.29.19-.55.06-.26-.13-1.08-.4-2.06-1.27-.76-.68-1.28-1.52-1.43-1.78-.15-.26-.02-.4.11-.53.12-.12.26-.31.39-.47.13-.16.17-.26.26-.44.09-.17.04-.32-.02-.45-.06-.13-.57-1.37-.78-1.88-.2-.49-.41-.42-.57-.43h-.49z"></path>
            </svg>
            <span class="sr-only">WhatsApp</span>
          </a>
          <a class="social-link" href="https://www.facebook.com/people/PC-MasterFix/100070017932247/" target="_blank" rel="noopener noreferrer" aria-label="Abrir Facebook de PC MasterFix">
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">
              <path d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5.02 3.66 9.18 8.44 9.94v-7.03H7.9v-2.91h2.54V9.84c0-2.52 1.49-3.91 3.78-3.91 1.1 0 2.25.2 2.25.2v2.48H15.2c-1.24 0-1.63.78-1.63 1.57v1.88h2.78l-.44 2.91h-2.34V22C18.34 21.24 22 17.08 22 12.06z"></path>
            </svg>
            <span class="sr-only">Facebook</span>
          </a>
          <a class="social-link" href="https://www.instagram.com/pcmasterfix096/" target="_blank" rel="noopener noreferrer" aria-label="Abrir Instagram de PC MasterFix">
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="3" y="3" width="18" height="18" rx="5"></rect>
              <circle cx="12" cy="12" r="4"></circle>
              <path d="M17.5 6.5h.01"></path>
            </svg>
            <span class="sr-only">Instagram</span>
          </a>
        </div>
      </div>
    </footer>
  </div>

  <script>
    (function () {
      var carousel = document.getElementById('internet-carousel');
      if (!carousel) {
        return;
      }

      var track = carousel.querySelector('.carousel-track');
      var slides = Array.prototype.slice.call(carousel.querySelectorAll('.plan-slide'));
      var dots = Array.prototype.slice.call(carousel.querySelectorAll('.carousel-dot'));
      var controls = Array.prototype.slice.call(carousel.querySelectorAll('[data-direction]'));
      var currentIndex = 0;
      var touchStartX = 0;

      function goToSlide(index) {
        currentIndex = (index + slides.length) % slides.length;
        track.style.transform = 'translateX(-' + (currentIndex * 100) + '%)';

        dots.forEach(function (dot, dotIndex) {
          dot.setAttribute('aria-current', dotIndex === currentIndex ? 'true' : 'false');
        });
      }

      controls.forEach(function (control) {
        control.addEventListener('click', function () {
          goToSlide(currentIndex + Number(control.dataset.direction));
        });
      });

      dots.forEach(function (dot) {
        dot.addEventListener('click', function () {
          goToSlide(Number(dot.dataset.slide));
        });
      });

      carousel.addEventListener('keydown', function (event) {
        if (event.key === 'ArrowLeft') {
          event.preventDefault();
          goToSlide(currentIndex - 1);
        }

        if (event.key === 'ArrowRight') {
          event.preventDefault();
          goToSlide(currentIndex + 1);
        }
      });

      carousel.addEventListener('touchstart', function (event) {
        touchStartX = event.changedTouches[0].screenX;
      }, { passive: true });

      carousel.addEventListener('touchend', function (event) {
        var deltaX = event.changedTouches[0].screenX - touchStartX;

        if (Math.abs(deltaX) > 45) {
          goToSlide(currentIndex + (deltaX < 0 ? 1 : -1));
        }
      }, { passive: true });

      goToSlide(0);
    }());
  </script>
</body>
</html>
