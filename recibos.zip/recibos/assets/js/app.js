const API = {
  insertar: 'api/insertar.php',
  buscar: 'api/buscar.php',
  autenticar: 'api/autenticar.php',
  actualizar: 'api/actualizar.php',
  eliminar: 'api/eliminar.php',
  recibo: 'api/generar_recibo.php',
  consultaGeneral: 'api/consulta_general.php',
  cerrarSesion: 'api/cerrar_sesion.php',
};

const CONSULTA_COLUMNS = [
  'NumServicio',
  'Nombre del Cliente',
  'Contraseña',
  'Fecha de Instalacion',
  'Modelo',
  'Número de Serie',
  'Megas',
  'Paquete',
  'Streaming',
  'Costo streaming',
  'Total final',
  'Estatus pago',
  'Numero de Telefono',
  'Cordenadas',
  'NAP',
];

const COLUMN_LABELS = {
  streaming_activo: 'Streaming',
  costo_streaming: 'Costo streaming',
  total_con_streaming: 'Total final',
  ESTATUSPAGO: 'Estatus',
};

const TABLES = {
  inventario_equipos: {
    title: 'Inventario Equipos',
    primary: 'NumServicio',
    auto: false,
    fields: [
      { name: 'NumServicio', label: 'NumServicio', type: 'text', pattern: '[A-Za-z0-9._-]{1,30}', placeholder: 'PMF001' },
      { name: 'Contraseña', label: 'Contraseña', type: 'password', maxlength: 255 },
      { name: 'Fecha de Instalacion', label: 'Fecha de Instalacion', type: 'date' },
      { name: 'Estatus', label: 'Estatus', type: 'select', options: ['Activo', 'Suspendido', 'Baja', 'Mantenimiento', 'Instalado'] },
      { name: 'Modelo', label: 'Modelo', type: 'text', maxlength: 100 },
      { name: 'Número de Serie', label: 'Número de Serie', type: 'text', maxlength: 120 },
      { name: 'Contrato', label: 'Contrato', type: 'text', maxlength: 120 },
      { name: 'Condición del equipo', label: 'Condición del equipo', type: 'select', options: ['Nuevo', 'Bueno', 'Regular', 'Dañado', 'En revision'] },
    ],
  },
  inventario_clientes: {
    title: 'Inventario Clientes',
    primary: 'NumServicio',
    auto: false,
    fields: [
      { name: 'NumServicio', label: 'NumServicio', type: 'text', pattern: '[A-Za-z0-9._-]{1,30}', placeholder: 'PMF001' },
      { name: 'Nombre del Cliente', label: 'Nombre del Cliente', type: 'text', maxlength: 150 },
      { name: 'Estatus', label: 'Estatus', type: 'select', options: ['Activo', 'Suspendido', 'Baja', 'Prospecto'] },
      { name: 'Megas', label: 'Megas', type: 'number', min: 1, step: 1 },
      { name: 'Numero de Telefono', label: 'Numero de Telefono', type: 'tel', pattern: '[0-9+\\-\\s()]{7,30}', placeholder: '294 000 0000' },
      { name: 'Colonia', label: 'Colonia', type: 'text', maxlength: 120 },
      { name: 'Municipio', label: 'Municipio', type: 'text', maxlength: 120 },
      { name: 'Cordenadas', label: 'Cordenadas', type: 'text', maxlength: 150, placeholder: '18.4650, -95.3000' },
    ],
  },
  pagos: {
    title: 'pagos',
    primary: 'id',
    auto: true,
    displayColumns: [
      'id',
      'SERVICIOS',
      'Paquete',
      'streaming_activo',
      'costo_streaming',
      'total_con_streaming',
      'ESTATUSPAGO',
      'MES',
      'AÑO',
      'COMENTARIO',
    ],
    fields: [
      { name: 'SERVICIOS', label: 'SERVICIOS', type: 'text', pattern: '[A-Za-z0-9._-]{1,30}', placeholder: 'PMF001' },
      { name: 'Paquete', label: 'Paquete', type: 'number', min: 0, step: '0.01' },
      { name: 'streaming_activo', label: 'Servicio streaming', type: 'select', options: [{ value: '0', label: 'No' }, { value: '1', label: 'Sí' }], value: '0' },
      { name: 'costo_streaming', label: 'Costo streaming', type: 'number', min: 0, step: '0.01', value: '30.00' },
      { name: 'ESTATUSPAGO', label: 'ESTATUSPAGO', type: 'select', options: ['Pagado', 'No pagado', 'Pendiente', 'Parcial', 'Vencido'] },
      { name: 'MES', label: 'MES', type: 'number', min: 1, max: 12, step: 1 },
      { name: 'AÑO', label: 'AÑO', type: 'number', min: 2000, max: 2100, step: 1 },
      { name: 'COMENTARIO', label: 'COMENTARIO', type: 'textarea', maxlength: 5000 },
    ],
  },
  diagrama_red: {
    title: 'DiagramaRed',
    primary: 'id',
    auto: true,
    fields: [
      { name: 'NumServicio', label: 'NumServicio', type: 'text', pattern: '[A-Za-z0-9._-]{1,30}', placeholder: 'PMF001' },
      { name: 'NAP', label: 'NAP', type: 'text', maxlength: 100 },
      { name: 'color', label: 'color', type: 'color', value: '#1f6f8b' },
    ],
  },
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

let recordStore = new Map();
let recordCounter = 0;
let currentSearchNumServicio = '';
let currentSearchPeriod = null;
let editState = null;
let authResolver = null;
let toastTimer = null;
let receiptData = null;
let adminAuth = null;
let requestedProtectedTab = null;
let sessionResetPromise = Promise.resolve();
let lastConsultaGeneral = null;

const PROTECTED_TABS = new Set(['ingresar', 'buscar']);

document.addEventListener('DOMContentLoaded', () => {
  resetAdminAccessOnLoad();
  setupTabs();
  renderInsertForms();
  setupSearch();
  setupConsultaGeneral();
  setupAuthDialog();
  setupEditDialog();
  setupReceipt();
});

function resetAdminAccessOnLoad() {
  adminAuth = null;
  requestedProtectedTab = null;
  sessionResetPromise = fetch(API.cerrarSesion, {
    method: 'POST',
    credentials: 'same-origin',
  }).catch(() => {
    // El acceso del frontend queda cerrado aunque el servidor no responda.
  });
}

function setupTabs() {
  $$('.tab-button').forEach((button) => {
    button.addEventListener('click', async () => {
      const tab = button.dataset.tab;

      if (PROTECTED_TABS.has(tab) && !adminAuth) {
        requestedProtectedTab = tab;
        const auth = await getAdminAuth();
        if (!auth) {
          requestedProtectedTab = null;
          showToast('Autenticacion requerida para acceder a esta seccion.', 'error');
          return;
        }
      }

      activateTab(requestedProtectedTab || tab);
      requestedProtectedTab = null;
    });
  });
}

function activateTab(tab) {
  $$('.tab-button').forEach((btn) => btn.classList.toggle('is-active', btn.dataset.tab === tab));
  $$('.tab-panel').forEach((panel) => panel.classList.toggle('is-active', panel.id === `tab-${tab}`));
}

function renderInsertForms() {
  const container = $('#formsGrid');
  container.innerHTML = '';

  Object.entries(TABLES).forEach(([tableKey, definition]) => {
    const form = document.createElement('form');
    form.className = 'record-form';
    form.dataset.table = tableKey;
    form.autocomplete = 'off';

    const header = document.createElement('header');
    const title = document.createElement('h2');
    title.textContent = definition.title;
    header.appendChild(title);
    form.appendChild(header);

    const grid = document.createElement('div');
    grid.className = 'form-grid';
    definition.fields.forEach((field) => grid.appendChild(createField(field, tableKey)));
    form.appendChild(grid);

    const row = document.createElement('div');
    row.className = 'button-row align-end';
    const submit = document.createElement('button');
    submit.className = 'button button-primary';
    submit.type = 'submit';
    submit.textContent = 'Guardar';
    row.appendChild(submit);
    form.appendChild(row);

    form.addEventListener('submit', handleInsertSubmit);
    container.appendChild(form);
  });
}

async function handleInsertSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const tableKey = form.dataset.table;
  const definition = TABLES[tableKey];

  if (!form.reportValidity()) {
    return;
  }

  const datos = collectFormData(form, definition.fields);

  try {
    const auth = await getAdminAuth();
    if (!auth) return;

    await postJson(API.insertar, { tabla: tableKey, datos, auth });
    showToast('Registro insertado correctamente.', 'success');
    form.reset();
    resetFieldDefaults(form, definition.fields);
  } catch (error) {
    showToast(error.message, 'error');
  }
}

function createField(field, tableKey, value = '') {
  const label = document.createElement('label');
  label.className = 'field';

  const span = document.createElement('span');
  span.textContent = field.label;
  label.appendChild(span);

  let input;
  if (field.type === 'select') {
    input = document.createElement('select');
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = 'Seleccione';
    input.appendChild(placeholder);

    field.options.forEach((optionConfig) => {
      const optionText = typeof optionConfig === 'object' ? optionConfig.label : optionConfig;
      const optionValue = typeof optionConfig === 'object' ? optionConfig.value : optionConfig;
      const option = document.createElement('option');
      option.value = optionValue;
      option.textContent = optionText;
      input.appendChild(option);
    });
  } else if (field.type === 'textarea') {
    input = document.createElement('textarea');
  } else {
    input = document.createElement('input');
    input.type = field.type;
  }

  input.name = field.name;
  input.id = makeFieldId(tableKey, field.name);
  input.required = true;

  if (field.pattern) input.pattern = field.pattern;
  if (field.placeholder) input.placeholder = field.placeholder;
  if (field.maxlength) input.maxLength = field.maxlength;
  if (field.min !== undefined) input.min = field.min;
  if (field.max !== undefined) input.max = field.max;
  if (field.step !== undefined) input.step = field.step;

  const initialValue = value !== '' && value !== null && value !== undefined ? String(value) : (field.value || '');
  if (initialValue !== '') {
    input.value = initialValue;
  }

  label.appendChild(input);
  return label;
}

function makeFieldId(tableKey, fieldName) {
  return `field-${tableKey}-${fieldName}`.replace(/[^A-Za-z0-9_-]/g, '-');
}

function collectFormData(form, fields) {
  const data = {};

  fields.forEach((field) => {
    const input = form.elements.namedItem(field.name);
    data[field.name] = input ? String(input.value).trim() : '';
  });

  return data;
}

function resetFieldDefaults(form, fields) {
  fields.forEach((field) => {
    if (field.value !== undefined) {
      const input = form.elements.namedItem(field.name);
      if (input) input.value = field.value;
    }
  });
}

function setupSearch() {
  const form = $('#searchForm');
  const results = $('#searchResults');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;

    const auth = await getAdminAuth();
    if (!auth) return;

    const numServicio = form.elements.namedItem('NumServicio').value.trim();
    await buscarServicio(numServicio, true, getSelectedSearchPeriod(form));
  });

  results.addEventListener('click', async (event) => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;

    const item = recordStore.get(button.dataset.recordId);
    if (!item) return;

    if (button.dataset.action === 'edit') {
      const auth = await getAdminAuth();
      if (auth) {
        openEditDialog(item.tableKey, item.record, auth);
      }
    }

    if (button.dataset.action === 'delete') {
      const confirmed = window.confirm('¿Eliminar este registro? Esta accion no se puede deshacer.');
      if (!confirmed) return;

      const auth = await getAdminAuth();
      if (!auth) return;

      try {
        await postJson(API.eliminar, {
          tabla: item.tableKey,
          clave: getRecordKey(item.tableKey, item.record),
          auth,
        });
        showToast('Registro eliminado correctamente.', 'success');
        if (currentSearchNumServicio) {
          await buscarServicio(currentSearchNumServicio, false, currentSearchPeriod);
        }
      } catch (error) {
        showToast(error.message, 'error');
      }
    }
  });
}

function setupConsultaGeneral() {
  const button = $('#queryAllButton');
  const results = $('#queryResults');
  const form = $('#searchForm');

  if (!button || !results) return;

  const now = new Date();
  const mesInput = form.elements.namedItem('consultaMES');
  const anioInput = form.elements.namedItem('consultaAnio');
  if (mesInput && !mesInput.value) mesInput.value = String(now.getMonth() + 1);
  if (anioInput && !anioInput.value) anioInput.value = String(now.getFullYear());

  button.addEventListener('click', async () => {
    const auth = await getAdminAuth();
    if (!auth) return;

    results.className = 'results empty-state';
    results.textContent = 'Generando consulta general...';

    try {
      const params = new URLSearchParams({
        MES: mesInput?.value || String(now.getMonth() + 1),
        AÑO: anioInput?.value || String(now.getFullYear()),
      });
      const data = await getJson(`${API.consultaGeneral}?${params.toString()}`);
      renderConsultaGeneral(data.registros || [], data);
      showToast('Consulta general generada.', 'success');
    } catch (error) {
      results.className = 'results empty-state';
      results.textContent = error.message;
      showToast(error.message, 'error');
    }
  });
}

function renderConsultaGeneral(records, payload = {}) {
  const results = $('#queryResults');
  results.className = 'results';
  results.innerHTML = '';
  lastConsultaGeneral = { records, payload };

  const section = document.createElement('section');
  section.className = 'record-section';

  const header = document.createElement('header');
  const h2 = document.createElement('h2');
  const periodo = payload.periodo ? ` ${payload.periodo.MES}/${payload.periodo['AÑO']}` : '';
  h2.textContent = `Consulta general${periodo}`;
  header.appendChild(h2);

  if (records.length) {
    const downloadButton = document.createElement('button');
    downloadButton.className = 'button button-secondary button-small';
    downloadButton.type = 'button';
    downloadButton.textContent = 'Descargar Excel';
    downloadButton.addEventListener('click', downloadConsultaGeneralExcel);
    header.appendChild(downloadButton);
  }

  section.appendChild(header);

  if (payload.resumen) {
    section.appendChild(renderConsultaSummary(payload.resumen));
  }

  if (!records.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = 'No hay registros para mostrar.';
    section.appendChild(empty);
    results.appendChild(section);
    return;
  }

  const wrap = document.createElement('div');
  wrap.className = 'table-wrap consulta-table-wrap';
  const table = document.createElement('table');
  table.className = 'data-table consulta-table';

  const thead = document.createElement('thead');
  const headRow = document.createElement('tr');
  CONSULTA_COLUMNS.forEach((column) => {
    const th = document.createElement('th');
    th.textContent = getColumnLabel(column);
    headRow.appendChild(th);
  });
  thead.appendChild(headRow);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  records.forEach((record) => {
    const tr = document.createElement('tr');
    CONSULTA_COLUMNS.forEach((column) => {
      const td = document.createElement('td');
      if (column === 'Estatus pago') {
        const badge = document.createElement('span');
        badge.className = `estatus-badge ${getEstatusClass(record[column])}`.trim();
        badge.textContent = record[column] ?? '';
        td.appendChild(badge);
      } else if (['Paquete', 'Costo streaming', 'Total final'].includes(column)) {
        td.textContent = formatMoney(record[column]);
      } else {
        td.textContent = record[column] ?? '';
      }
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });

  table.appendChild(tbody);
  wrap.appendChild(table);
  section.appendChild(wrap);
  results.appendChild(section);
}

function renderConsultaSummary(resumen) {
  const summary = document.createElement('div');
  summary.className = 'summary-grid';

  [
    ['Total paquetes', resumen.total_paquetes],
    ['Total streaming', resumen.total_streaming],
    ['Total final', resumen.total_final],
  ].forEach(([label, value]) => {
    const item = document.createElement('div');
    item.className = 'summary-item';
    const span = document.createElement('span');
    span.textContent = label;
    const strong = document.createElement('strong');
    strong.textContent = formatMoney(value);
    item.appendChild(span);
    item.appendChild(strong);
    summary.appendChild(item);
  });

  return summary;
}

function downloadConsultaGeneralExcel() {
  if (!lastConsultaGeneral || !lastConsultaGeneral.records.length) {
    showToast('Primero genera una consulta general con registros.', 'error');
    return;
  }

  const { records, payload } = lastConsultaGeneral;
  const periodo = payload.periodo || {};
  const mes = periodo.MES || '';
  const anio = periodo['AÑO'] || '';
  const workbook = buildConsultaGeneralExcelXml(records, payload);
  const blob = new Blob([workbook], {
    type: 'application/vnd.ms-excel;charset=utf-8',
  });
  const filename = `consulta_general_${safeFilePart(mes)}_${safeFilePart(anio)}.xls`;
  downloadBlob(blob, filename);
  showToast('Archivo Excel descargado.', 'success');
}

function buildConsultaGeneralExcelXml(records, payload = {}) {
  const periodo = payload.periodo || {};
  const resumen = payload.resumen || {};
  const title = `Consulta general ${periodo.MES || ''}/${periodo['AÑO'] || ''}`.trim();
  const rows = [];

  rows.push(excelRow([title], 'Title', CONSULTA_COLUMNS.length - 1));
  rows.push(excelRow(['Total paquetes', resumen.total_paquetes || '0.00', 'Total streaming', resumen.total_streaming || '0.00', 'Total final', resumen.total_final || '0.00'], 'Summary'));
  rows.push('<Row/>');
  rows.push(excelRow(CONSULTA_COLUMNS.map(getColumnLabel), 'Header'));

  records.forEach((record) => {
    rows.push(excelRow(CONSULTA_COLUMNS.map((column) => formatConsultaExcelValue(column, record[column]))));
  });

  return `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
  xmlns:o="urn:schemas-microsoft-com:office:office"
  xmlns:x="urn:schemas-microsoft-com:office:excel"
  xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
  <Styles>
    <Style ss:ID="Title">
      <Font ss:Bold="1" ss:Size="14"/>
      <Interior ss:Color="#DDEBF7" ss:Pattern="Solid"/>
    </Style>
    <Style ss:ID="Summary">
      <Font ss:Bold="1"/>
      <Interior ss:Color="#E2F0D9" ss:Pattern="Solid"/>
    </Style>
    <Style ss:ID="Header">
      <Font ss:Bold="1"/>
      <Interior ss:Color="#F2F2F2" ss:Pattern="Solid"/>
    </Style>
  </Styles>
  <Worksheet ss:Name="Consulta general">
    <Table>
      ${rows.join('\n      ')}
    </Table>
  </Worksheet>
</Workbook>`;
}

function formatConsultaExcelValue(column, value) {
  if (['Paquete', 'Costo streaming', 'Total final'].includes(column)) {
    return Number(value || 0).toFixed(2);
  }

  return value ?? '';
}

function excelRow(values, styleId = '', mergeAcross = 0) {
  const style = styleId ? ` ss:StyleID="${styleId}"` : '';
  const cells = values.map((value, index) => {
    const merge = index === 0 && mergeAcross > 0 ? ` ss:MergeAcross="${mergeAcross}"` : '';
    return `<Cell${style}${merge}><Data ss:Type="String">${escapeXml(value)}</Data></Cell>`;
  }).join('');

  return `<Row>${cells}</Row>`;
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

function safeFilePart(value) {
  return String(value || 'consulta').replace(/[^A-Za-z0-9_-]/g, '_');
}

function escapeXml(value) {
  return String(value ?? '').replace(/[<>&"']/g, (char) => ({
    '<': '&lt;',
    '>': '&gt;',
    '&': '&amp;',
    '"': '&quot;',
    "'": '&apos;',
  }[char]));
}

function getColumnLabel(column) {
  return COLUMN_LABELS[column] || column;
}

async function buscarServicio(numServicio, showSuccess = true, periodo = currentSearchPeriod) {
  const results = $('#searchResults');
  results.className = 'results empty-state';
  results.textContent = 'Buscando registros...';

  try {
    const params = new URLSearchParams({ NumServicio: numServicio });
    if (periodo?.MES && periodo?.AÑO) {
      params.set('MES', periodo.MES);
      params.set('AÑO', periodo.AÑO);
    }
    const data = await getJson(`${API.buscar}?${params.toString()}`);
    currentSearchNumServicio = data.NumServicio;
    currentSearchPeriod = periodo || null;
    renderSearchResults(data);
    if (showSuccess) showToast('Busqueda completada.', 'success');
  } catch (error) {
    currentSearchNumServicio = '';
    currentSearchPeriod = null;
    recordStore = new Map();
    results.className = 'results empty-state';
    results.textContent = error.message;
    showToast(error.message, 'error');
  }
}

function getSelectedSearchPeriod(form = $('#searchForm')) {
  const mes = form?.elements.namedItem('consultaMES')?.value.trim() || '';
  const anio = form?.elements.namedItem('consultaAnio')?.value.trim() || '';

  return mes && anio ? { MES: mes, AÑO: anio } : null;
}

function renderSearchResults(data) {
  const results = $('#searchResults');
  results.className = 'results';
  results.innerHTML = '';
  recordStore = new Map();
  recordCounter = 0;

  if (data.equipo) {
    results.appendChild(renderRecordSection('Inventario Equipos', 'inventario_equipos', data.equipo));
  }

  if (data.cliente) {
    results.appendChild(renderRecordSection('Inventario Clientes', 'inventario_clientes', data.cliente));
  }

  const pagosTitle = currentSearchPeriod ? `pagos (${currentSearchPeriod.MES}/${currentSearchPeriod.AÑO})` : 'pagos';
  results.appendChild(renderTableSection(pagosTitle, 'pagos', data.pagos || []));
  results.appendChild(renderTableSection('DiagramaRed', 'diagrama_red', data.diagramaRed || []));
}

function renderRecordSection(title, tableKey, record) {
  const section = document.createElement('section');
  section.className = 'record-section';

  const header = document.createElement('header');
  const h2 = document.createElement('h2');
  h2.textContent = title;
  header.appendChild(h2);
  header.appendChild(createActionGroup(registerRecord(tableKey, record)));
  section.appendChild(header);

  const dl = document.createElement('dl');
  dl.className = 'kv-grid';
  const columns = TABLES[tableKey].fields.map((field) => field.name);

  columns.forEach((column) => {
    const item = document.createElement('div');
    item.className = 'kv-item';

    const dt = document.createElement('dt');
    dt.textContent = column;
    const dd = document.createElement('dd');
    dd.textContent = record[column] ?? '';

    item.appendChild(dt);
    item.appendChild(dd);
    dl.appendChild(item);
  });

  section.appendChild(dl);
  return section;
}

function renderTableSection(title, tableKey, records) {
  const section = document.createElement('section');
  section.className = 'record-section';

  const header = document.createElement('header');
  const h2 = document.createElement('h2');
  h2.textContent = title;
  header.appendChild(h2);
  section.appendChild(header);

  if (!records.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = `No hay registros en ${title} para este servicio.`;
    section.appendChild(empty);
    return section;
  }

  const wrap = document.createElement('div');
  wrap.className = 'table-wrap';
  const table = document.createElement('table');
  table.className = 'data-table';

  const columns = TABLES[tableKey].displayColumns || (TABLES[tableKey].auto
    ? [TABLES[tableKey].primary, ...TABLES[tableKey].fields.map((field) => field.name)]
    : TABLES[tableKey].fields.map((field) => field.name));

  const thead = document.createElement('thead');
  const headRow = document.createElement('tr');
  columns.concat(['Acciones']).forEach((column) => {
    const th = document.createElement('th');
    th.textContent = getColumnLabel(column);
    headRow.appendChild(th);
  });
  thead.appendChild(headRow);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  records.forEach((record) => {
    const tr = document.createElement('tr');
    columns.forEach((column) => {
      const td = document.createElement('td');
      appendCellValue(td, tableKey, column, record[column], record);
      tr.appendChild(td);
    });

    const tdActions = document.createElement('td');
    tdActions.appendChild(createActionGroup(registerRecord(tableKey, record)));
    tr.appendChild(tdActions);
    tbody.appendChild(tr);
  });

  table.appendChild(tbody);
  wrap.appendChild(table);
  section.appendChild(wrap);
  return section;
}

function appendCellValue(td, tableKey, column, value, record = {}) {
  if (tableKey === 'pagos' && column === 'ESTATUSPAGO') {
    const badge = document.createElement('span');
    badge.className = `estatus-badge ${getEstatusClass(value)}`.trim();
    badge.textContent = value ?? '';
    td.appendChild(badge);
    return;
  }

  if (tableKey === 'pagos' && column === 'streaming_activo') {
    td.textContent = isStreamingActive(value) ? 'Sí' : 'No';
    return;
  }

  if (tableKey === 'pagos' && column === 'total_con_streaming') {
    td.textContent = formatMoney(getPaymentTotals(record).total);
    return;
  }

  if (tableKey === 'pagos' && ['Paquete', 'costo_streaming'].includes(column)) {
    td.textContent = formatMoney(value);
    return;
  }

  td.textContent = value ?? '';
}

function isStreamingActive(value) {
  return String(value ?? '').toLowerCase() === '1' || String(value ?? '').toLowerCase() === 'si' || String(value ?? '').toLowerCase() === 'sí';
}

function getEstatusClass(value) {
  const normalized = normalizeText(value);

  if (normalized === 'pagado') {
    return 'estatus-pagado';
  }

  if (normalized === 'no pagado' || normalized === 'vencido') {
    return 'estatus-no-pagado';
  }

  if (normalized === 'pendiente' || normalized === 'parcial') {
    return 'estatus-pendiente';
  }

  return '';
}

function normalizeText(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

function formatMoney(value) {
  const amount = Number(value || 0);
  return `$${amount.toFixed(2)}`;
}

function createActionGroup(recordId) {
  const actions = document.createElement('div');
  actions.className = 'record-actions';

  const edit = document.createElement('button');
  edit.className = 'button button-secondary button-small';
  edit.type = 'button';
  edit.dataset.action = 'edit';
  edit.dataset.recordId = recordId;
  edit.textContent = 'Modificar';

  const del = document.createElement('button');
  del.className = 'button button-danger button-small';
  del.type = 'button';
  del.dataset.action = 'delete';
  del.dataset.recordId = recordId;
  del.textContent = 'Eliminar';

  actions.appendChild(edit);
  actions.appendChild(del);
  return actions;
}

function registerRecord(tableKey, record) {
  const id = `${tableKey}-${++recordCounter}`;
  recordStore.set(id, { tableKey, record });
  return id;
}

function getRecordKey(tableKey, record) {
  return record[TABLES[tableKey].primary];
}

function setupAuthDialog() {
  const dialog = $('#authDialog');
  const form = $('#authForm');
  const error = $('#authError');
  const submitButton = form.querySelector('button[type="submit"]');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;

    const usuario = form.elements.namedItem('usuario').value.trim();
    const password = form.elements.namedItem('password').value;

    try {
      submitButton.disabled = true;
      submitButton.textContent = 'Validando...';
      const response = await postJson(API.autenticar, { usuario, password });
      closeAuthDialog({ usuario, password, token: response.token });
    } catch (err) {
      error.textContent = err.message;
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = 'Continuar';
    }
  });

  $$('[data-close-auth], #authCancel').forEach((button) => {
    button.addEventListener('click', () => closeAuthDialog(null));
  });

  dialog.addEventListener('cancel', (event) => {
    event.preventDefault();
    closeAuthDialog(null);
  });
}

function solicitarAuth() {
  const dialog = $('#authDialog');
  const form = $('#authForm');
  $('#authError').textContent = '';
  form.reset();

  return new Promise((resolve) => {
    authResolver = resolve;
    dialog.showModal();
    setTimeout(() => form.elements.namedItem('usuario').focus(), 50);
  });
}

async function getAdminAuth() {
  await sessionResetPromise;

  if (adminAuth) {
    return adminAuth;
  }

  const auth = await solicitarAuth();
  if (!auth) {
    return null;
  }

  adminAuth = auth;
  showToast('Acceso autorizado.', 'success');
  return adminAuth;
}

function closeAuthDialog(result) {
  const dialog = $('#authDialog');
  if (authResolver) {
    authResolver(result);
    authResolver = null;
  }
  if (dialog.open) dialog.close();
}

function setupEditDialog() {
  const dialog = $('#editDialog');
  const form = $('#editForm');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity() || !editState) return;

    const definition = TABLES[editState.tableKey];
    const datos = collectFormData(form, definition.fields);

    try {
      await postJson(API.actualizar, {
        tabla: editState.tableKey,
        clave: editState.key,
        datos,
        auth: editState.auth,
      });

      showToast('Registro actualizado correctamente.', 'success');
      closeEditDialog();
      if (currentSearchNumServicio) {
        const nextSearch = datos.NumServicio || datos.SERVICIOS || currentSearchNumServicio;
        await buscarServicio(nextSearch, false, currentSearchPeriod);
      }
    } catch (error) {
      $('#editError').textContent = error.message;
    }
  });

  $$('[data-close-edit], #editCancel').forEach((button) => {
    button.addEventListener('click', closeEditDialog);
  });

  dialog.addEventListener('cancel', (event) => {
    event.preventDefault();
    closeEditDialog();
  });
}

function openEditDialog(tableKey, record, auth) {
  const dialog = $('#editDialog');
  const fields = $('#editFields');
  const definition = TABLES[tableKey];

  editState = {
    tableKey,
    key: getRecordKey(tableKey, record),
    auth,
  };

  $('#editTitle').textContent = `Modificar ${definition.title}`;
  $('#editError').textContent = '';
  fields.innerHTML = '';
  definition.fields.forEach((field) => {
    fields.appendChild(createField(field, `edit-${tableKey}`, record[field.name] ?? ''));
  });

  dialog.showModal();
}

function closeEditDialog() {
  const dialog = $('#editDialog');
  editState = null;
  if (dialog.open) dialog.close();
}

function setupReceipt() {
  const form = $('#receiptForm');
  const loadButton = $('#loadReceiptClient');
  const now = new Date();

  form.elements.namedItem('MES').value = String(now.getMonth() + 1);
  form.elements.namedItem('AÑO').value = String(now.getFullYear());

  ['MES', 'AÑO'].forEach((fieldName) => {
    form.elements.namedItem(fieldName).addEventListener('change', () => {
      if (receiptData) renderReceiptPreview(receiptData);
    });
  });

  loadButton.addEventListener('click', async () => {
    await loadReceiptClient();
  });

  form.elements.namedItem('NumServicio').addEventListener('change', () => {
    receiptData = null;
    $('#receiptPreview').className = 'receipt-preview empty-state';
    $('#receiptPreview').textContent = 'Carga un cliente para preparar el recibo.';
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;

    try {
      const data = await ensureReceiptData();
      const numServicio = form.elements.namedItem('NumServicio').value.trim();
      const mes = form.elements.namedItem('MES').value.trim();
      const anio = form.elements.namedItem('AÑO').value.trim();
      const megasConsumidos = form.elements.namedItem('megasConsumidos').value.trim();
      const megasContratados = Number(data.cliente?.Megas || megasConsumidos);
      const grafica = drawReceiptChart(Number(megasConsumidos), megasContratados);

      const response = await fetch(API.recibo, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          NumServicio: numServicio,
          MES: mes,
          AÑO: anio,
          megasConsumidos,
          grafica,
        }),
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({ mensaje: 'No se pudo generar el PDF.' }));
        throw new Error(error.mensaje || 'No se pudo generar el PDF.');
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const filename = `recibo_${sanitizeFilename(numServicio)}_${mes}_${anio}.pdf`;
      const opened = window.open(url, '_blank');

      if (!opened) {
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
      }

      setTimeout(() => URL.revokeObjectURL(url), 60000);
      showToast('PDF generado correctamente.', 'success');
    } catch (error) {
      showToast(error.message, 'error');
    }
  });
}

async function ensureReceiptData() {
  const form = $('#receiptForm');
  const numServicio = form.elements.namedItem('NumServicio').value.trim();

  if (!receiptData || receiptData.NumServicio !== numServicio) {
    return loadReceiptClient();
  }

  return receiptData;
}

async function loadReceiptClient() {
  const form = $('#receiptForm');
  const numServicio = form.elements.namedItem('NumServicio').value.trim();

  if (!numServicio) {
    showToast('Captura el numero de servicio.', 'error');
    form.elements.namedItem('NumServicio').focus();
    throw new Error('Falta NumServicio.');
  }

  try {
    const params = new URLSearchParams({ NumServicio: numServicio });
    const data = await getJson(`${API.buscar}?${params.toString()}`);

    if (!data.cliente) {
      throw new Error('El servicio no tiene datos de cliente.');
    }

    receiptData = data;
    const megasInput = form.elements.namedItem('megasConsumidos');
    if (!megasInput.value) {
      megasInput.value = data.cliente.Megas || '';
    } else {
      megasInput.value = data.cliente.Megas || megasInput.value;
    }

    renderReceiptPreview(data);
    showToast('Cliente cargado para recibo.', 'success');
    return data;
  } catch (error) {
    receiptData = null;
    showToast(error.message, 'error');
    throw error;
  }
}

function renderReceiptPreview(data) {
  const preview = $('#receiptPreview');
  const cliente = data.cliente;
  const receiptPayment = getReceiptPaymentForSelectedPeriod(data);
  const pagoRecibo = receiptPayment.payment;
  const estatusRecibo = receiptPayment.status;
  const detallePago = getPaymentTotals(pagoRecibo);
  preview.className = 'receipt-preview';
  preview.innerHTML = `
    <dl>
      <div>
        <dt>Numero de servicio</dt>
        <dd>${escapeHtml(data.NumServicio)}</dd>
      </div>
      <div>
        <dt>Cliente</dt>
        <dd>${escapeHtml(cliente['Nombre del Cliente'] || '')}</dd>
      </div>
      <div>
        <dt>Colonia</dt>
        <dd>${escapeHtml(cliente.Colonia || '')}</dd>
      </div>
      <div>
        <dt>Megas contratados</dt>
        <dd>${escapeHtml(cliente.Megas || '')}</dd>
      </div>
      <div>
        <dt>Subtotal / paquete base</dt>
        <dd>${escapeHtml(formatMoney(detallePago.subtotal))} MXN</dd>
      </div>
      <div>
        <dt>Servicio de streaming</dt>
        <dd>${detallePago.streamingActivo ? 'Sí' : 'No'}</dd>
      </div>
      <div>
        <dt>Costo streaming</dt>
        <dd>${escapeHtml(formatMoney(detallePago.costoStreaming))} MXN</dd>
      </div>
      <div>
        <dt>Total final</dt>
        <dd>${escapeHtml(formatMoney(detallePago.total))} MXN</dd>
      </div>
      <div>
        <dt>Estatus del recibo</dt>
        <dd><span class="estatus-badge ${getEstatusClass(estatusRecibo)}">${escapeHtml(estatusRecibo)}</span></dd>
      </div>
    </dl>
  `;
}

function getPaymentTotals(payment = {}) {
  const subtotal = Number(payment.Paquete || 0);
  const streamingActivo = isStreamingActive(payment.streaming_activo);
  const costoBase = Number(payment.costo_streaming ?? 30);
  const costoStreaming = streamingActivo ? costoBase : 0;
  const total = payment.total_con_streaming !== undefined
    ? Number(payment.total_con_streaming || 0)
    : subtotal + costoStreaming;

  return {
    subtotal,
    streamingActivo,
    costoStreaming,
    total,
  };
}

function getReceiptPaymentForSelectedPeriod(data) {
  const form = $('#receiptForm');
  const mes = Number(form.elements.namedItem('MES').value);
  const anio = Number(form.elements.namedItem('AÑO').value);
  const pagos = data.pagos || [];
  const matchingPayment = pagos.find((pago) => Number(pago.MES) === mes && Number(pago['AÑO']) === anio);
  const latestPayment = pagos[0] || {};

  return {
    payment: matchingPayment || latestPayment,
    status: matchingPayment?.ESTATUSPAGO || 'Pendiente',
  };
}

function drawReceiptChart(megasConsumidos, megasContratados) {
  const canvas = $('#receiptChartCanvas');
  const ctx = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;
  const max = Math.max(megasConsumidos, megasContratados, 1);
  const chart = { x: 86, y: 42, w: 730, h: 180 };
  const barWidth = 130;
  const barHeight = Math.max(10, (megasConsumidos / max) * chart.h);
  const barX = chart.x + chart.w / 2 - barWidth / 2;
  const barY = chart.y + chart.h - barHeight;

  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = '#17202a';
  ctx.font = '700 28px Arial';
  ctx.fillText('Megas consumidos en el mes', 42, 34);

  ctx.strokeStyle = '#d9e2ec';
  ctx.lineWidth = 2;
  ctx.strokeRect(chart.x, chart.y, chart.w, chart.h);

  ctx.beginPath();
  ctx.moveTo(chart.x, chart.y + chart.h);
  ctx.lineTo(chart.x + chart.w, chart.y + chart.h);
  ctx.strokeStyle = '#94a3b8';
  ctx.stroke();

  ctx.fillStyle = '#1f6f8b';
  ctx.fillRect(barX, barY, barWidth, barHeight);

  ctx.fillStyle = '#c8553d';
  const lineY = chart.y + chart.h - ((megasContratados / max) * chart.h);
  ctx.fillRect(chart.x, lineY, chart.w, 4);

  ctx.fillStyle = '#17202a';
  ctx.font = '700 24px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(`${megasConsumidos} Mbps`, barX + barWidth / 2, Math.max(72, barY - 12));
  ctx.font = '16px Arial';
  ctx.fillText('Consumo', barX + barWidth / 2, chart.y + chart.h + 32);

  ctx.textAlign = 'right';
  ctx.fillStyle = '#c8553d';
  ctx.font = '700 16px Arial';
  ctx.fillText(`Contratados: ${megasContratados} Mbps`, chart.x + chart.w, Math.max(18, lineY - 8));

  ctx.textAlign = 'left';
  return canvas.toDataURL('image/jpeg', 0.92);
}

async function postJson(url, payload) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    body: JSON.stringify(payload),
  });

  const data = await response.json().catch(() => ({ ok: false, mensaje: 'Respuesta JSON invalida.' }));

  if (!response.ok || data.ok === false) {
    throw new Error(data.mensaje || 'Error del servidor.');
  }

  return data;
}

async function getJson(url) {
  const response = await fetch(url, { credentials: 'same-origin' });
  const data = await response.json().catch(() => ({ ok: false, mensaje: 'Respuesta JSON invalida.' }));

  if (!response.ok || data.ok === false) {
    throw new Error(data.mensaje || 'Error del servidor.');
  }

  return data;
}

function showToast(message, type = '') {
  const toast = $('#toast');
  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.className = `toast is-visible ${type}`.trim();
  toastTimer = window.setTimeout(() => {
    toast.className = 'toast';
  }, 4200);
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;',
  }[char]));
}

function sanitizeFilename(value) {
  return String(value).replace(/[^A-Za-z0-9_-]/g, '_');
}
